# AG03 Memory Life Context — Draft 0.5.1 Extract

### AG03 — Memory & Life Context

**Status:** DESIGN implementing OD-02; not an independently approved runtime deployment.

**When to call.** Relevant prior context may improve a response, a participant asks to remember/correct/forget something, or a review requires eligible history.

**Responsibility.** Retrieve the right approved context and prepare visible optional continuity notes; maintain distinctions between enduring, seasonal, temporary, historical and uncertain information without building a covert biography.

**Inputs.** Purpose-specific task; selected record types/time scope; current permission/lifecycle revisions; approved Blueprint/continuity references; participant exclusions and corrections.

**Retrieval scope.** Only authorized current/historical records useful for the task. No deleted/expired/legal-hold-only sources, unrelated people, contact lists, private admin cases or raw transcript archive.

**Permitted tool families.** Scoped retrieval; selected-note proposal; participant-requested correction/exclusion/deletion-status route. All actual persistence/deletion uses protected services and receipts.

**Output.** A compact evidence-linked context set with exact approved anchors, dated reports, uncertainties, relevant names/labels, previously answered items and topics not to ask. Optional note proposals identify purpose and eligible uses.

**Write authority.** No automatic autobiographical memory or hidden summary store. No saving sensitive disclosures solely because they seem meaningful. A generated summary is not participant-approved truth.

**Prohibitions and boundaries.** Storage, personalization, annual review, resurfacing and sharing are separate. Source deletion must not be bypassed through a derivative. Names can personalize ordinary guidance, not prospecting or pricing. Do not repeatedly ask questions already answered or deliberately declined. Separate selected-note permission from registration and notice acknowledgment. No durable starting note without participant choice and a separate externally supplied save confirmation under Q07; no imported failed-run biography.

**Failure / uncertainty behavior.** State that prior information is unavailable or may be stale; use the present conversation without pretending full recall. Handle ambiguous relationships with a targeted question.

**Source basis.** ARCH B/F–H; PRIV §§4–5/13; OD-15/16; master 05.

**Required tests:** D02-051, D02-052, D02-053, D02-054, V2-C09, D04-001, D04-002, D04-003, D04-004, D04-005. Current candidate execution remains NOT RUN; prior D02-001 failure is preserved separately.
