# RT-Q07-PARTIAL Controller Events

See Focused_Retest_Plan_Draft_0_5_1.md for fixture, procedure and expected criteria. Record actual transcript, candidate identity, controller events, reviewer, pass/fail and limitations. Do not infer application pass from conversation behavior.
