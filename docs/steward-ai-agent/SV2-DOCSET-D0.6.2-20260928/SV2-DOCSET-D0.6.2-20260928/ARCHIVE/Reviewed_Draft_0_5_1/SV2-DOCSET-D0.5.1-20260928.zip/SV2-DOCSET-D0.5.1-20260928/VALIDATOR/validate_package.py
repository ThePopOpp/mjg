#!/usr/bin/env python3
import sys, zipfile, hashlib, json, re
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
sources=list((root/'PROJECT_SOURCES').glob('*'))
print('PROJECT_SOURCES files:', len(sources))
assert len(sources)==12
assert (root/'PROJECT_SOURCES'/'Statement-of-Faith.txt').exists()
pi=(root/'PROJECT_INSTRUCTIONS.txt').read_text()
print('PROJECT_INSTRUCTIONS LF chars:', len(pi))
print('PROJECT_INSTRUCTIONS CRLF chars:', len(pi.replace('\n','\r\n')))
assert len(pi)<8000 and len(pi.replace('\n','\r\n'))<8000
print('OK')
