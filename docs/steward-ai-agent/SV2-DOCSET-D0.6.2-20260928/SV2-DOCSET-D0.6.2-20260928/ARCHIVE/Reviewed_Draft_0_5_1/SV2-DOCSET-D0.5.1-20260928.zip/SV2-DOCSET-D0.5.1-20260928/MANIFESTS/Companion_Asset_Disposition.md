# Companion Asset Disposition — Draft 0.5.1

Restored/current companions in this package include S00 and AG01–AG09 prompt extracts; common prompt; agent registry; offer catalogue example; DEC09 benefit/lifecycle example; feature catalogue; grant/group templates; promotion-attention examples; annual/monthly presentation example; referral action-status examples; release templates; controller event template; focused retest run guides; validator; test catalogue; original Draft 0.3 owner-reported failure artifact; Batch 01 reports/register; source preservation evidence; native availability and source-completeness records.

The fixed Draft 0.4 active source masters are archived under `ARCHIVE/Draft_0_4_Inputs/PROJECT_SOURCES`. The reviewed Draft 0.5 ZIP is preserved under `ARCHIVE/Preinstallation_Reviewed_Draft_0_5/`.

Unprovided native originals, older external historical ZIPs, artwork and private source files are not claimed to be inside this ZIP. Live references to previous SOURCE_COMPLETENESS or Native_Source_Availability records resolve to the files included in this package. No nested historical ZIP copies are added except the single reviewed Draft 0.5 ZIP preserved as requested history.
