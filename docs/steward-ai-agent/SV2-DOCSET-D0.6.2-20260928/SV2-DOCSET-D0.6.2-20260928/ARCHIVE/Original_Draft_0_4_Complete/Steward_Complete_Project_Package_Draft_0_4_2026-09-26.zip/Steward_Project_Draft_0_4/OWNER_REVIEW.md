# Steward Draft 0.4 — targeted correction

SV2-DOCSET-D0.4-20260926; CHG-D02-001-001; defect DEF-D02-001-001. Internal Steward V2.0; eventual Steward V1.0 — Initial Full Build.

The prior D02-001 conversation is FAIL as reported by Mike; no complete transcript or real application failure is asserted. Adult status was declared. Jordan/name-email did not authorize the invented verification/notice acknowledgments/account receipts. The proposed starting note was neither approved nor saved. Evidence is preserved in EVIDENCE/D02-001_Draft_0_3_Owner_Report.json.

Steward now must present fictional setup choices and wait, distinguish inputs/choices/application confirmations, and accept simulated results only from Mike's TEST CONTROLLER EVENT or an implemented authorized harness. It cannot create those events. Partial states remain pending; valid completed setup returns to the original concern. Note/Blueprint adoption and save confirmation remain separate. Applicable authentication/MFA/access protections stay intact. Test notices are not production legal terms.

Five regression definitions cover name/email only, missing acknowledgment, reported versus confirmed verification, partial results, and valid completed setup with conversation return and separate saving. All Draft 0.4 executions are NOT RUN. This correction is documented, not proven to pass. No harness/application was implemented or tested.

Compact C2 derives from the located C1 file and replaces the oversized 9,157-character package instructions. Exact C2 count: **7,409 characters**, including spaces and LF line breaks; **7,441** if converted to CRLF. EVIDENCE/Instruction_Length.json records hashes and method.

Historical modules, exact faith, all unrelated approved product/commercial directions and the previous Draft 0.3 ZIP are unchanged. Install per START_HERE.md. Installation alone does not restart D02-001. Use a fresh test chat later and TESTING/FRESH_CHAT_RERUN_PROMPT.txt when ready.
