# Steward DEC-09 — New recurring first-year offer

**Status: PROPOSAL / DESIGN — OWNER CHOICE NOT YET RECORDED.**

Prepared September 26, 2026. Base review snapshot: **SV2-DOCSET-D0.2-20260926**. Internal project: **Steward V2.0**. Intended eventual handoff: **Steward V1.0 — Initial Full Build**.

Proposed change identifier: **CHG-DEC09-001**. This companion proposes exact terms and an implementation/change map. It does not amend the twelve supplied sources, publish an offer, authorize participant charges, or establish a new application/documentation release.

## Recommended owner decision

Select a new offer for initial Full acquisition: **$299 plus applicable tax for Full Build and the first 12 calendar months of Steward Premium; then $199 plus applicable tax every 12 calendar months until canceled.** The first-year service clock and annual renewal anniversary begin at explicit participant activation, not purchase. Preserve the existing activation and trust-refund protections by expressly applying them to this new offer. Existing Full owners use qualified continuation instead of buying Full again.

This matches the recorded recurring intent while keeping renewal aligned with the existing $199 annual continuation reference price. It does not make the $299 price annual recurring revenue, promise unlimited use, or guarantee permanent renewal pricing. Actual delivery economics and usage allowances remain separate configuration/evidence work. [11: OD-10, AMD-04, DEC-09; 07: M02, M09–M10]

## Source acceptance and review boundary

All twelve named PROJECT_SOURCES are physically present and readable in the supplied workspace. All eleven Markdown masters identify Draft 0.2 and the exact active package ID. The intentional numbering gap is not a missing 01 source.

The exact supplied **Statement-of-Faith.txt** was read in full: 2,633 bytes, fourteen headings from God through Identity, including Life, the five solas, Marriage and Identity. Its SHA-256 is `b587d8af30ad22d695e48d78608cc6cbbf05d928cd3c6527c58ca305ac9e4e87`. No text is substituted or amended. This fingerprints the supplied bytes; no separately supplied earlier original or preservation manifest is available for an independent cross-version comparison.

Read the complete current sections of masters 00 and 11, including OD-01–19, AMD-01–12, all 27 original direction entries, 13 added feature families, INV-01–20 and DEC-01–14. Read the complete preserved **COM** and **PJ** modules for the inherited commercial and journey rules under review, then applied the precise current amendments. Read the relevant current conversation, journey, data, engineering and test contracts. This is a focused DEC-09 review, not a full semantic audit of every preserved teaching, safety or privacy module.

The available masters contain 29 matching BEGIN_SOURCE/END_SOURCE module pairs. That structural count does not establish original native-file fidelity. Accept the recorded owner-confirmed 69-member original handoff and three separate engineering briefs as history. Do not invent a missing Jeremy Production Build Brief. Native originals, archive/evidence companions, actual application code, actual configuration files and Jeremy receipt were not supplied here. Premium direction/notice provenance remains complete preserved indexed text, not verified native DOCX bytes. [00 §§4–9; 11 §§8–9]

The current registers distinguish recorded direction from DESIGN and release evidence. Nothing in this proposal reopens assessment-optional entry, registration, nine functions, useful Free/Premium, helpful upgrades/referrals, configurable discounts/grants, Inner Circle/groups or church-affiliation-only scope. Their existing boundaries and explicit deferrals remain current. The material gap for DEC-09 is an exact new offer version; the older nonrenewing rule is not a veto on the new recurring direction.

## Three distinct agreements

| Offer | Payment and service | Renewal |
| --- | --- | --- |
| Existing $149 Initial Full Blueprint Build | One-time purchase; explicit activation starts 30 calendar days of guided Build. The 90-day unused-activation/refund and 14-day post-activation refund rules remain. | No automatic membership. Qualified $19/month or $199/year continuation is separately chosen after the Build window under existing timing rules. |
| Legacy `BUILD_LIVE_299_Y1` | One-time prepaid Full Build plus 12 calendar months; Build and Steward start together at activation. | Nonrenewing. Honor every actual purchased snapshot. Continuing afterward requires a new affirmative $19/month or $199/year agreement. |
| Proposed new recurring bundle | $299 plus applicable tax initially; initial Full acquisition, 30-day Build and 12-month Premium term. | $199 plus applicable tax annually from the activation anniversary until canceled, under an expressly accepted new agreement. |

The new recurring bundle is a separate immutable offer version, never an edit to `BUILD_LIVE_299_Y1`. New retail discovery would use the new offer only after its release; legacy fulfillment, access, refunds and nonrenewal remain supported. No customer migration or subscription is created merely because this document recommends the new offer. [07 M02–M05; COM §§2,5,8–12; COM D01–D10]

## Exact proposed terms

| Topic | Proposed treatment |
| --- | --- |
| Initial price | USD 299.00 base plus applicable tax, with the actual total displayed before authorization. No invented $149/$150 accounting allocation. |
| Eligibility | Initial Full has not already been validly acquired; verified participant identity, current qualification and overlap checks. An assessment or completed Free Blueprint is not required. |
| Recurring authorization | Checkout separately and conspicuously records assent to $299 now and $199 annually beginning 12 calendar months after explicit activation, unless canceled. No preselected consent or marketing bundle. The activation action confirms the actual first renewal date and the same accepted terms. Payment or approval of Blueprint wording alone is not authorization. |
| Activation | Explicit participant action within 90 calendar days of confirmed initial payment. Activation requires confirmed payment, committed benefits and available authorized service. No background activation from purchase, first login, assessment completion or a webhook. |
| First service term | At activation A, begin one 30-calendar-day Build window and one 12-calendar-month Premium interval concurrently. The Build period is inside the paid year. Ongoing Premium can refine or finish the same acquired Full Blueprint after the Build window without another Build charge. |
| Anniversary | First renewal at A + 12 calendar months; then annual renewal on the governed anniversary. Use the existing calendar arithmetic, last-valid-day handling, recorded offer timezone and start-inclusive/end-exclusive intervals. Initial configuration: America/Phoenix, UTC instants stored. Changing display timezone does not move the purchased interval. Reconcile actual provider invoice periods to the configured promise. |
| No activation | Full refund available before activation. At the end of the 90-day window, initiate a full refund for a genuinely unused/unactivated purchase and stop any pending future-renewal instructions. A failed refund remains an unresolved money/service obligation. Activation and refund processing must be mutually exclusive. |
| Cancel renewal | Available directly in account controls from purchase onward, including before activation. Confirmed cancellation prevents future charges. By default it preserves the already-purchased service: before activation, the right to activate within the original window; afterward, access through the confirmed paid-through date. Activation never re-arms canceled renewal. Immediate termination, refund and account deletion remain separate actions. |
| Initial package refund | Full refund before activation or when requested within 14 calendar days after activation, including meaningful use. No routine partial package allocation. A confirmed full unwind ends only package-funded grants and that acquisition’s qualification; it must also stop associated future renewal. Created Blueprint content, Free access and independently valid grants remain. Cancellation and refund still have separate requests, operations and receipts. |
| Annual renewal refund | Full refund of the affected renewal charge if requested within 14 calendar days of that charge. Its confirmed refund removes that continuation interval, not the previously valid initial Full acquisition. Display and confirm future cancellation separately; a refund receipt alone is not proof billing stopped. Outside ordinary windows, retain existing error, undelivered-service and mandatory-remedy handling. |
| Failed renewal | Explicitly apply the existing fixed seven-calendar-day grace policy to the first $199 renewal after the bundled year, as well as subsequent annual renewals. No grace for an unsuccessful initial purchase. Retries cannot restart grace; unresolved grace ends in Free/retained-content access and the reviewed collection disposition. |
| Notices | Proposed product default: a factual annual renewal notice 30 calendar days before renewal, an activation receipt showing the exact first renewal date, and a receipt after each confirmed charge. Actual legally required timing/channel/acknowledgment rules remain release review, not certified here. Billing notices are separate from optional marketing and the month-11 review. |
| Cadence changes | An eligible participant may deliberately select the published $19/month continuation for the end of the paid annual term, with fresh cadence assent. No routine midterm proration, overlapping agreements or automatic monthly fallback after a failed annual charge. |
| Later prices | Purchased terms are immutable. Higher renewal price or cadence change requires fresh affirmative acceptance; without it, stop renewal at the current term’s end. The $199 proposal is not a lifetime price guarantee. |
| Discounts and grants | Existing configurable mechanisms remain. Each discounted offer explicitly states whether the reduction applies to the initial charge, renewal charges or a limited duration. No-card grants remain independent and nonbilling; group membership cannot turn them into this offer. |
| After paid service ends | Retain legitimately created Blueprint content, secure eligible viewing/export and useful Free access under existing policy. No annual repeat Build charge, forced new Blueprint, deletion for nonrenewal or promotion of content/definition states. |

Example for date interpretation only: purchase October 1, activate October 20; Premium runs October 20 to the following October 20, and renewal is due at that service anniversary. The purchase date is not the annual billing anchor. No actual transaction or account is implied.

## Precise policy amendment boundary

The proposed terms expressly select details left OPEN by DEC-09. They do not rewrite preserved COM/PJ source bodies.

1. Extend the current AMD-04 disposition to identify the selected new offer, initial charge, annual renewal phase, activation anniversary, assent, notice and unwind rules. COM D02/§§2.1,5.2,6.1,11.3,14.2 and CE04 remain the preserved legacy contract; current supplements distinguish new versus legacy applicability.
2. Explicitly adopt COM D01/D08 activation and initial-refund protections for the new recurring version. They do not apply by accident merely because the new offer also costs $299.
3. Explicitly extend COM D07/§11.2 to the first renewal following the bundled prepaid year. The older wording covers previously paid monthly/annual continuation; leaving its application to the new first renewal implicit would create an avoidable gap.
4. Carry forward COM D03–D06 and D09–D14 where unchanged: Full qualification, no duplicate Full purchase, continuation timing, source overlap, direct cancellation, assent for price/cadence increases, tax review, source-specific disputes and delegated authority.
5. Checkout/provider mechanics need an actual reviewed implementation: a model must not choose a Stripe mode or create a schedule from prose. The business invariant is one initial payment, one independently recorded recurring mandate, no renewal before the confirmed anniversary, and no duplicate or orphan agreement. [08 E09–E12]

## Exact source-file change map if selected

Only current authored sections/supplements would change. All 29 preserved module bodies and the Statement of Faith remain byte-for-byte unchanged.

| Existing file | Exact target | Proposed edit |
| --- | --- | --- |
| `00_Control_Register.md` | §5; candidate/version/change references in §§2,8–9 | Replace the unresolved DEC-09 summary with the selected decision reference only after Mike selects it. Record the next documentation candidate and changed-file hashes without inventing an application release or closing evidence gates. |
| `11_Change_Impact_Decisions.md` | OD-10, AMD-04, DEC-09; controlled change-notice supplement | Record the exact owner choice, date and scope; distinguish selection from review/implementation/release. Add CHG-DEC09-001 with the scoped D01/D07/D08 application and legacy exclusions. Preserve historical CN-SV2-002 and all original modules. No change to the 27-entry/13-family scope selections. |
| `07_Commerce_Scripture_Rights.md` | M02–M03, M05–M06, M09–M10; new current DEC-09 schedule/test crosswalk | Add the new immutable offer schedule, explicit activation/refund/grace rules, future-renewal cancellation before activation, notices and cadence handling. Keep separate legacy offer treatment and actual cash/recurring revenue reporting. RIGHTS remains untouched. |
| `04_Product_Journey_New_Features.md` | J02, X03, X05, P07–P08 cross-reference | Map offer cards and purchase/activation/return flow to the selected catalogue version. Keep month-11 review and My Next Season independent of renewal consent, annual charging and new Full acquisition. |
| `05_Data_Privacy_Security.md` | D18–D20 current DESIGN contracts | Explicit references for immutable offer snapshot, recurring assent version/time, activation, first-renewal anchor, cancellation fence, service/invoice intervals, notice receipts and change manifest. Map into existing record families; a new physical table or raw-content retention is not presumed necessary. |
| `08_Engineering_Experience_Operations.md` | E05–E07, E09–E12; current commerce implementation supplement | Specify authoritative offer retrieval, activation-bound renewal scheduling, idempotent payment/grant reconciliation, cancellation/refund races, version-specific UI and staged rollout. Keep reviewed obligations serviced on rollback; disable new sales without reviving old consent or charges. Historical UX/ADMIN/KICKOFF bodies stay intact. |
| `09_Test_Suite_Quality_Control.md` | Q04/current supplement; Q01 count only after additions | Retain D02-034 and the 158 existing cases; add the 12 proposed DEC09 cases below. Attach new-offer fixtures to relevant current regressions. COM CE04 stays the legacy nonrenewing test; add a new recurring counterpart instead of replacing it. If all 12 are adopted, the current additional catalogue becomes 170 definitions, all NOT RUN until execution. |

No substantive edit is needed for `02_Framework_Blueprint_Assessments.md`, `03_Conversation_Sensitive_Safety.md`, `06_Safety_Support_Release.md`, `10_Teaching_Reference_Library.md` or `Statement-of-Faith.txt`. Their applicable controls remain dependencies. In particular, generic offer lookup and promotion restraint already cover this offer; prices should not be copied into prompts. The release evidence dossier would reference the applicable existing safety/privacy/rights/commerce gates without marking them closed.

## Configuration and implementation delta

No CONFIG directory, provider configuration or application repository was supplied. Therefore the following are proposed configuration artifacts and logical changes, not claims about existing code paths. A future release manifest must record Jeremy’s actual paths and versions.

Suggested companion artifact names: `CONFIG/dec09_recurring_offer.design.json`, `CONFIG/dec09_benefits.design.json` and `CONFIG/dec09_lifecycle_policies.design.json`. These names are NEW proposals. They are not files created or published by this response.

| Configuration area | Required proposed values / behavior |
| --- | --- |
| Offer identity | Stable existing family `build_plus_first_year`; new candidate `offer_version_id=build_plus_first_year_recurring_v1`; `currency=USD`; `initial_amount_minor=29900`; `renewal_amount_minor=19900`; annual recurrence. Identity is proposed until assigned. Legacy alias `BUILD_LIVE_299_Y1` is not mutated. |
| Publication state | `status=DESIGN`; `enabled=false`; owner-selection reference absent until real selection; required reviews/tests/release references absent until actual evidence. Missing required terms or gates block publication. |
| Qualification | `includes_initial_full=true`; reject an already-valid Full acquisition and conflicting personal agreement; preserve existing qualified continuation paths. |
| Benefits | Full acquisition, one initial Build grant of 30 calendar days, one initial Premium grant of 12 calendar months, common explicit activation; continuation grants only for confirmed invoice-funded periods. No new Full acquisition on renewal. |
| Activation/anniversary | Activation deadline 90 calendar days from confirmed payment; `renewal_anchor=confirmed_activation`; initial timezone America/Phoenix; calendar-month/last-valid-day handling; stored immutable UTC interval endpoints and provider-period reconciliation. |
| Billing/assent | $299 initial phase plus $199 annual continuation phase; exact displayed offer/terms/refund/assent versions retained; one personal agreement; pending renewal is canceled on full initial unwind or nonactivation refund. Separate affirmative choice for any later cadence change. |
| Refund/cancellation | Initial full refund before activation or within 14 calendar days afterward; unused refund at 90 days; renewal refund request within 14 calendar days of charge. Direct cancel, paid-through access, preactivation cancel preservation, independent receipts and retained-content behavior. |
| Grace/dunning | One seven-calendar-day grace from prior paid-through end, including first bundle renewal. Retry/final invoice disposition must be separately configured and tested; no invented retry schedule or indefinite off-service collection. |
| Notices | Product proposal: annual notice 30 calendar days before renewal; actual renewal date/price, direct cancel link, activation and payment receipts. Jurisdiction/channel overrides require qualified review. Review invitations and promotion budgets remain separate. |
| Discounts/grants | Versioned initial-versus-renewal discount scope; deterministic arithmetic; no hidden recurring consent or changes to unrelated grants. Preserve no-card and source-overlap behavior. |
| Provider/operations | New environment-specific product/price/schedule mappings as required by the actual adapter; pinned API, event handling, portal, tax, cancellation and dunning configuration. Exact vendor mechanics and IDs require discovery and testing; no external provider capability is verified here. |
| Rollout/recovery | New-sales flag remains off until release. Staging uses synthetic accounts/provider test mode. Rollback respects purchased contracts, pending refunds and cancellation/deletion fences; it cannot convert a recurring contract into legacy terms or restart canceled billing. |

## Proposed new acceptance definitions

All following IDs are NEW proposed definitions under CHG-DEC09-001. **Status of every case: NOT RUN.** Synthetic fixtures only; no participant simulation or application test was executed in this review. Actual runs must use the Q03 evidence schema and capture candidate, offer, policy, configuration, provider and reviewer identities.

| New ID | Fixture and procedure | Required observable result | Existing source/test anchors |
| --- | --- | --- | --- |
| DEC09-T01 | Create synthetic $149, legacy $299, incomplete new offer and fully selected-but-unreleased new offer. Attempt publish, checkout and automatic renewal. | One-time and legacy agreements stay nonrenewing. Missing terms, missing selection or unmet gates deny publication. Complete owner selection alone does not enable charges. | D02-034, D02-061; COM CE03–04, CE31; M02/AMD-04 |
| DEC09-T02 | Eligible initial buyer completes checkout with and without explicit recurring assent; repeat with already-qualified Full owner and tampered price. | Exact $299/$199 phases and activation rule shown; absent assent prevents recurring offer acceptance. Full owner uses continuation; no second Build charge or client-selected price. | D02-015; COM CE01–03, CE07, CE19–20 |
| DEC09-T03 | Pay on one date, activate later; replay activation; test month-end/leap-day and display-timezone changes; simulate unavailable service. | One common 30-day/12-month activation start, immutable anniversary and no extra post-Build months. No activation or clock consumption while unavailable; retries do not restart clocks. | COM CE04, CE35–36; D02-017 |
| DEC09-T04 | Leave new offer unactivated for 90 days; race activation against refund; force refund failure. | One permissible transition, full refund initiated if unused, pending renewal stopped, no future charge or forfeiture while funds remain unresolved. No application of retail deadline to sponsor fixtures. | COM CE22, CE35, CE49 |
| DEC09-T05 | Advance activated offer to first and second renewal; deliver duplicate/out-of-order provider events. | First and later renewal base is $199 under accepted terms; exact paid invoice interval grants once; no new Full fee or Build grant, no duplicate agreement or time stacking. | COM CE06–11; D02-017, D02-029 |
| DEC09-T06 | Cancel before activation, during first year, at renewal and during provider outage/account closure. | Future charging stopped as confirmed; preactivation cancel still permits original paid activation without re-arming renewal; active paid term preserved; unknown stays pending; contrary in-flight charge enters correction; closure leaves no orphan billing. | COM CE12–13, CE24, CE32, CE45, CE50 |
| DEC09-T07 | Request first-year refund just inside/outside 14-day activation window; request renewal refund inside/outside charge window; repeat with independent Full grant. | Policy deadlines use request time. Initial unwind removes only its acquisition/components and stops linked renewal. Renewal-only refund preserves initial Full qualification. Other grants and created content survive; no private-content inspection or double refund. Future billing state separately disclosed. | COM CE22–23, CE37, CE49; D02-050 |
| DEC09-T08 | Fail initial payment, first bundle renewal and later renewal; retry repeatedly and deliver late success after collection closure. | No initial grace; exactly seven calendar days at eligible renewals with no reset; then Free/retained access. Final collection disposition and late success reconcile; no silent new interval or recurring fallback. | COM CE41; scoped COM D07 addition |
| DEC09-T09 | Choose monthly at term end; receive sponsor grant while paid; race competing agreements and activation. | Explicit cadence assent, one agreement, existing period honored; no automatic proration or duplicate charge. Sponsor activation follows approved deferral; sponsor expiry does not restart billing. | D02-032–033; COM CE14–18, CE25–26, CE39 |
| DEC09-T10 | Change catalogue price, apply initial-only discount, propose higher renewal without acceptance and issue unrelated no-card grant. | Purchased snapshots hold; initial discount does not become permanent; no higher-price/cadence charge without assent; no-card grant never becomes billing; exact tax/total requires valid configuration. | D02-025–030; COM CE20, CE40, CE42–44 |
| DEC09-T11 | Compare website/chat/checkout/activation/account/notice copy; decline promotion; run month-11 review separately from billing. | Same offer terms on every surface; required notices factual and separate from selling; refusal honored; review approval creates no payment consent or new Blueprint. No private content in commerce, notices or support evidence. | D02-011–018, D02-029, D02-065; V2-P07-A/B, V2-P08-A/B; COM CE21, CE28, CE40, CE46 |
| DEC09-T12 | Disable new sales or restore an older configuration after synthetic purchase, cancellation, refund and permission revocation; attempt privileged/model writes. | Purchase obligations and needed servicing remain traceable; no recreated canceled mandate, lost refund task, resurrected deleted content or enabled route through a flag. Only authorized application transactions write commerce facts. | D02-058–064; COM CE19, CE29, CE34, CE47–50 |

Existing regressions are retained, not rewritten wholesale. D02-034 continues to test incomplete-offer blocking and legacy protection. Add new-offer variants to D02-015–018, D02-025–030, D02-032–034, D02-050, D02-058–065 and the relevant COM cases listed above. Preserve COM CE04 as an explicit legacy fixture. Keep COM CE01–CE50/RG01–RG30 and all other inherited test/gate registers intact; the new cases supplement them.

## Remaining decisions and evidence after this choice

DEC-09 selection would settle the product terms only. DEC-02/03 still require lifecycle/physical mapping and purpose review; DEC-04 exact notification/channel configuration; DEC-08 initial actual group/Inner Circle benefits; DEC-10 visual proof; DEC-11 actual operating/provider/usage settings; DEC-12 candidate acceptance/handoff; DEC-13 serving-rights evidence; DEC-14 missing-native limitations. DEC-01 execution/acceptance remains distinct from confirmed scope. DEC-05/06/07 are recorded deferral/no-expansion positions, not questions to re-ask now.

Required commercial reviews remain COM RV01–RV10 as applicable, particularly actual terms/recurring assent, tax/accounting, privacy and payment/security. Gates including RG08–RG20, RG22 and RG27–RG30 need actual candidate-specific evidence; inherited core release gates also remain. This proposal makes no current legal, tax, vendor-capability or production-readiness determination and performs no new outside research.

## Work actually completed

- Read and inventoried the twelve supplied sources; checked all eleven snapshot headers.
- Read the exact Statement of Faith and calculated its byte fingerprint.
- Reviewed the current registers and complete COM/PJ preserved modules, applying current amendments.
- Counted 29 paired preserved module markers and 158 unique current behavior/application test IDs.
- Produced this separate decision proposal, file/configuration delta and twelve proposed test definitions.

No governing source body, project instruction, application, provider account or live configuration was changed. No behavior/application test was executed; all 158 supplied cases and these 12 proposed cases remain NOT RUN. No owner selection, qualified approval, deployment, new project installation, participant transaction or Jeremy delivery/receipt is claimed.

**Next owner choice:** select the proposed $299 first year → $199 annual renewal agreement with explicit activation and the protections above, or change a specific term. Selection would authorize the scoped drafting update; it would not itself authorize production billing.
