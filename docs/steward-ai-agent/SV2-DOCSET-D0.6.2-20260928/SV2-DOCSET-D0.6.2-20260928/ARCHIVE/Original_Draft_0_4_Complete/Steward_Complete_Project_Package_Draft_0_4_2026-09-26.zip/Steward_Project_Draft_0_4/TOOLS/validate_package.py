#!/usr/bin/env python3
"""Validate a Steward documentation folder or ZIP without deploying or executing it.

Checks file hashes, exact supplied-source preservation and catalogue structure.
This does NOT validate an application's security, behavior, legal compliance or rights.
A self-contained hash manifest proves consistency, not trusted author identity.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import re
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath

MAX_TOTAL = 256 * 1024 * 1024
PACKAGE_ID = 'SV2-DOCSET-D0.4-20260926'
BASE_PACKAGE_SHA256 = '9c5c4f7972afa5b509aa806c7c3acc122cdafc70c2f2e924e3c4df32ea8f36fa'
FAITH_SHA256 = 'b587d8af30ad22d695e48d78608cc6cbbf05d928cd3c6527c58ca305ac9e4e87'
MASTERS = [
 '00_Control_Register.md','02_Framework_Blueprint_Assessments.md',
 '03_Conversation_Sensitive_Safety.md','04_Product_Journey_New_Features.md',
 '05_Data_Privacy_Security.md','06_Safety_Support_Release.md',
 '07_Commerce_Scripture_Rights.md','08_Engineering_Experience_Operations.md',
 '09_Test_Suite_Quality_Control.md','10_Teaching_Reference_Library.md',
 '11_Change_Impact_Decisions.md','Statement-of-Faith.txt']

class ValidationError(Exception):
    pass

def safe_name(name: str) -> None:
    p = PurePosixPath(name)
    if '\\' in name or p.is_absolute() or any(x in ('..', '.') for x in name.split('/')) or ':' in name:
        raise ValidationError(f'Unsafe path: {name!r}')

def load_files(path: Path) -> dict[str, bytes]:
    result: dict[str, bytes] = {}
    if path.is_dir():
        total=0
        for f in sorted(path.rglob('*')):
            if f.is_symlink():
                raise ValidationError(f'Symlink is not allowed: {f}')
            if not f.is_file():
                continue
            name=f.relative_to(path).as_posix()
            safe_name(name)
            total += f.stat().st_size
            if total > MAX_TOTAL:
                raise ValidationError('Package exceeds document validation size limit')
            result[name]=f.read_bytes()
    else:
        with zipfile.ZipFile(path) as z:
            infos=z.infolist()
            if sum(i.file_size for i in infos)>MAX_TOTAL:
                raise ValidationError('Archive exceeds document validation size limit')
            seen=set()
            files=[]
            for i in infos:
                name=i.filename.rstrip('/')
                if not name:
                    continue
                safe_name(name)
                if name in seen:
                    raise ValidationError(f'Duplicate archive member: {name}')
                seen.add(name)
                if stat.S_ISLNK(i.external_attr >> 16):
                    raise ValidationError('Archive symlink rejected')
                if not i.is_dir():
                    files.append(i)
            roots={i.filename.split('/')[0] for i in files}
            prefix=''
            if 'PACKAGE_MANIFEST.json' not in {i.filename for i in files}:
                if len(roots)!=1:
                    raise ValidationError('Expected one package root')
                prefix=next(iter(roots))+'/'
            for i in files:
                name=i.filename[len(prefix):]
                safe_name(name)
                if name in result:
                    raise ValidationError(f'Duplicate normalized member: {name}')
                result[name]=z.read(i)
    return result

def validate(path: Path) -> dict:
    files=load_files(path)
    if 'PACKAGE_MANIFEST.json' not in files:
        raise ValidationError('Missing PACKAGE_MANIFEST.json')
    manifest=json.loads(files['PACKAGE_MANIFEST.json'])
    if manifest['package_id']!=PACKAGE_ID or manifest['test_case_count']!=175 or manifest['production_authorized'] is not False:
        raise ValidationError('Current candidate identity/count/release boundary mismatch')
    records=manifest['files']
    declared=[r['path'] for r in records]
    if len(set(declared)) != len(declared):
        raise ValidationError('Duplicate manifest entry')
    expected=set(declared)|{'PACKAGE_MANIFEST.json','SHA256SUMS.txt'}
    if set(files)!=expected:
        raise ValidationError(f'Inventory mismatch. Missing={sorted(expected-set(files))}; unexpected={sorted(set(files)-expected)}')
    for rec in records:
        safe_name(rec['path'])
        data=files[rec['path']]
        if len(data)!=rec['bytes'] or hashlib.sha256(data).hexdigest()!=rec['sha256']:
            raise ValidationError(f'Checksum/size mismatch: {rec["path"]}')
    checksum_lines=files['SHA256SUMS.txt'].decode('utf-8').splitlines()
    sum_paths=set()
    for line in checksum_lines:
        digest, name=line.split('  ',1)
        if name in sum_paths or name=='SHA256SUMS.txt' or name not in files:
            raise ValidationError('Invalid checksum-list path')
        sum_paths.add(name)
        if hashlib.sha256(files[name]).hexdigest()!=digest:
            raise ValidationError(f'SHA256SUMS mismatch: {name}')
    if sum_paths != set(files)-{'SHA256SUMS.txt'}:
        raise ValidationError('SHA256SUMS inventory mismatch')
    for name in MASTERS:
        if any(prefix+name not in files for prefix in ('PROJECT_SOURCES/','ARCHIVE/Draft_0_1_Inputs/','ARCHIVE/Draft_0_2_Inputs/','ARCHIVE/Draft_0_3_Inputs/')):
            raise ValidationError(f'Missing active/input master {name}')
    sf=files['PROJECT_SOURCES/Statement-of-Faith.txt']
    if (sf!=files['ARCHIVE/Draft_0_1_Inputs/Statement-of-Faith.txt'] or
        sf!=files['ARCHIVE/Draft_0_2_Inputs/Statement-of-Faith.txt'] or
        sf!=files['ARCHIVE/Draft_0_3_Inputs/Statement-of-Faith.txt'] or
        hashlib.sha256(sf).hexdigest()!=FAITH_SHA256):
        raise ValidationError('Statement of Faith was changed')
    previous=files['ARCHIVE/Draft_0_2_Previous_Candidate.zip']
    if hashlib.sha256(previous).hexdigest()!=BASE_PACKAGE_SHA256:
        raise ValidationError('Archived previous candidate ZIP changed')
    with zipfile.ZipFile(io.BytesIO(previous)) as z:
        if len(z.infolist())!=77:
            raise ValidationError('Previous candidate inventory changed')
        for name in MASTERS:
            if z.read('Steward_Project_Draft_0_2/PROJECT_SOURCES/'+name)!=files['ARCHIVE/Draft_0_2_Inputs/'+name]:
                raise ValidationError(f'Previous candidate input differs: {name}')
    d03=files['ARCHIVE/Draft_0_3_Previous_Candidate.zip']
    if hashlib.sha256(d03).hexdigest()!='c2ee1439331f222c9691bd3b1c993db977b0fc0feff4893567cacce321ac1a95':
        raise ValidationError('Draft 0.3 archive changed')
    with zipfile.ZipFile(io.BytesIO(d03)) as z:
        if len(z.infolist())!=100:
            raise ValidationError('Draft 0.3 archive inventory changed')
        for name in MASTERS:
            if z.read('Steward_Project_Draft_0_3/PROJECT_SOURCES/'+name)!=files['ARCHIVE/Draft_0_3_Inputs/'+name]:
                raise ValidationError('Draft 0.3 input differs: '+name)
    c1=files['ARCHIVE/Draft_0_3_C1/PROJECT_INSTRUCTIONS_Draft_0_3_Under_8000.txt']
    if hashlib.sha256(c1).hexdigest()!='4bc8d3cbfea8e908d0c2b5e4d3d2b9d15891146255b25d9c0d3e3e3625515a55':
        raise ValidationError('Compact C1 archive changed')
    instructions=files['PROJECT_INSTRUCTIONS.txt'].decode('utf-8')
    measured=json.loads(files['EVIDENCE/Instruction_Length.json'])
    if (len(instructions)>=7500 or instructions.startswith('\ufeff') or
        len(instructions)!=measured['characters_including_spaces_and_line_breaks'] or
        len(instructions)+instructions.count('\n')!=measured['characters_if_all_LF_are_CRLF'] or
        hashlib.sha256(files['PROJECT_INSTRUCTIONS.txt']).hexdigest()!=measured['sha256'] or
        'DRAFT 0.4 / COMPACT C2' not in instructions):
        raise ValidationError('Compact instruction identity/count/headroom mismatch')
    count=0; blocks=0
    for name in MASTERS:
        if not name.endswith('.md'):
            continue
        old=files['ARCHIVE/Draft_0_1_Inputs/'+name].decode('utf-8')
        base=files['ARCHIVE/Draft_0_2_Inputs/'+name].decode('utf-8')
        new=files['PROJECT_SOURCES/'+name].decode('utf-8')
        if PACKAGE_ID not in new.split('# Full preserved source modules')[0]:
            raise ValidationError(f'Current master package ID missing: {name}')
        def modules(text):
            found=re.findall(r'<!-- BEGIN_SOURCE ([\w-]+) -->(.*?)<!-- END_SOURCE \1 -->',text,re.S)
            if len({k for k,_ in found})!=len(found):
                raise ValidationError('Duplicate module IDs')
            return dict(found)
        om,nm=modules(old),modules(new)
        if om!=nm or modules(base)!=nm or modules(files['ARCHIVE/Draft_0_3_Inputs/'+name].decode('utf-8'))!=nm:
            raise ValidationError(f'Preserved source body changed in {name}')
        count+=len(om)
        for key,body in om.items():
            ids=re.findall(r'<a id="'+re.escape(key)+r'-B(\d+)"></a>',body)
            nums=[int(x) for x in ids]
            if nums and (nums!=list(range(1,len(nums)+1))):
                raise ValidationError(f'Invalid source block sequence {key}')
            blocks+=len(nums)
    if count!=29:
        raise ValidationError(f'Expected 29 source modules, found {count}')
    suite=files['PROJECT_SOURCES/09_Test_Suite_Quality_Control.md'].decode('utf-8')
    old_ids=re.findall(r'^### (V2-(?:P\d\d-[AB]|S\d\d-[AB]|C\d\d|X\d\d)) —',suite,re.M)
    new_ids=re.findall(r'^### (D02-\d{3}) —',suite,re.M)
    dec_ids=re.findall(r'^### (DEC09-T\d{2}) —',suite,re.M)
    d04_ids=re.findall(r'^### (D04-\d{3}) —',suite,re.M)
    if (len(old_ids)!=86 or len(set(old_ids))!=86 or len(new_ids)!=72 or len(set(new_ids))!=72 or
        dec_ids!=[f'DEC09-T{i:02}' for i in range(1,13)] or d04_ids!=[f'D04-{i:03}' for i in range(1,6)]):
        raise ValidationError('Test heading count/uniqueness mismatch')
    index=json.loads(files['EVIDENCE/Test_Catalogue.json'])
    if any(t['status']!='NOT RUN' for t in index['new_cases']+index['preserved_cases']+index['dec09_cases']+index['d04_cases']):
        raise ValidationError('Unexpected claimed current-candidate behavior test result')
    if ({t['id'] for t in index['new_cases']}!=set(new_ids) or {t['id'] for t in index['preserved_cases']}!=set(old_ids) or
        {t['id'] for t in index['dec09_cases']}!=set(dec_ids) or {t['id'] for t in index['d04_cases']}!=set(d04_ids)):
        raise ValidationError('Test index mismatch')
    report=json.loads(files['EVIDENCE/D02-001_Draft_0_3_Owner_Report.json'])
    case=next(t for t in index['new_cases'] if t['id']=='D02-001')
    if (report['conversation_result']!='FAIL' or report['full_transcript_supplied'] is not False or
        report['verbatim_exchanges'] is not None or report['real_application_failure_established'] is not False or
        report['proposed_starting_note']['participant_approved'] is not False or
        report['proposed_starting_note']['saved'] is not False or
        any(v!='NOT RUN' for v in report['real_application_results'].values()) or
        case['prior_results'][0]['conversation_result']!='FAIL'):
        raise ValidationError('Prior reported failure provenance or evidence boundary changed')
    eng=files['PROJECT_SOURCES/08_Engineering_Experience_Operations.md'].decode('utf-8')
    agent_ids=re.findall(r'^### (AG\d\d) —',eng,re.M)
    if agent_ids!=[f'AG{i:02}' for i in range(1,10)]:
        raise ValidationError('Nine-function roster mismatch')
    for aid in agent_ids:
        body=re.search(r'^### '+aid+r' —.*?(?=^### AG\d\d —|^## E05)',eng,re.M|re.S).group(0).strip()
        matches=[data.decode('utf-8') for name,data in files.items() if name.startswith('AGENT_PROMPTS/'+aid+'_')]
        if len(matches)!=1 or matches[0].split('### '+aid,1)[-1].strip()!=body.split('### '+aid,1)[-1].strip():
            raise ValidationError(f'Agent extract differs from current master: {aid}')
    shared=eng.split('## E03 —',1)[1].split('## E04 —',1)[0].strip()
    if shared not in files['AGENT_PROMPTS/S00_Participant_Steward.md'].decode('utf-8'):
        raise ValidationError('Shared Steward extract differs from master')
    product=files['PROJECT_SOURCES/04_Product_Journey_New_Features.md'].decode('utf-8')
    pids=re.findall(r'^## ([PS]\d\d) —',product,re.M)
    if len(pids)!=27 or len(set(pids))!=27:
        raise ValidationError('Original direction catalogue incomplete')
    for name,data in files.items():
        if name.endswith('.json'):
            json.loads(data)
        if name.startswith('CONFIG/') and name.endswith('.json'):
            obj=json.loads(data)
            def inspect(o):
                if isinstance(o,dict):
                    for k,v in o.items():
                        if k in ('production_enabled','production_authorized') and v is not False:
                            raise ValidationError(f'Unsafe enabled example in {name}')
                        inspect(v)
                elif isinstance(o,list):
                    for v in o: inspect(v)
            inspect(obj)
            if obj.get('package_id')!=PACKAGE_ID:
                raise ValidationError(f'Configuration package ID mismatch: {name}')
    catalogue=json.loads(files['CONFIG/offer_catalogue.example.json'])
    offers={o['id']:o for o in catalogue['offers']}
    offer=offers['build_plus_first_year_recurring_v1']
    if (offer['price_minor']!=29900 or offer['renewal_terms']['price_minor']!=19900 or
        offer['renewal_terms']['calendar_months']!=12 or offer['requires_explicit_recurring_assent'] is not True or
        offer['renewal_terms']['anchor']!='CONFIRMED_EXPLICIT_ACTIVATION' or
        offer['activation_ui']['label']!='Activate Premium and continue with Steward' or
        offer['activation_ui']['repeat_intake'] is not False or offer['assessment_required'] is not False or
        offers['initial_full_reference']['billing']!='ONE_TIME' or
        offers['build_first_year_LEGACY_REFERENCE_ONLY']['billing']!='ONE_TIME_PREPAID_NO_AUTORENEW' or
        catalogue['global']['live_provider_price_ids'] is not None):
        raise ValidationError('Approved offer/activation/legacy boundary differs')
    benefits=json.loads(files['CONFIG/dec09_benefits.example.json'])
    if (benefits['initial_build']['calendar_days']!=30 or benefits['initial_premium']['calendar_months']!=12 or
        benefits['active_premium']['after_initial_build_window'] is not True or
        benefits['active_premium']['continue_building_same_full'] is not True or
        benefits['active_premium']['additional_initial_full_fee'] is not False):
        raise ValidationError('Approved continued-building benefit differs')
    lifecycle=json.loads(files['CONFIG/dec09_lifecycle_policies.example.json'])
    if (lifecycle['activation']['deadline_calendar_days_from_confirmed_payment']!=90 or
        lifecycle['refund']['initial_post_activation_request_calendar_days']!=14 or
        lifecycle['refund']['annual_charge_request_calendar_days']!=14 or
        lifecycle['renewal_grace']['calendar_days']!=7 or
        lifecycle['renewal_grace']['includes_first_bundle_renewal'] is not True or
        lifecycle['notices']['annual_advance_calendar_days']!=30 or
        lifecycle['cancel']['activation_does_not_rearm_canceled_mandate'] is not True):
        raise ValidationError('Approved lifecycle values differ')
    run=json.loads(files['TESTING/D02-001_Run_State.json'])
    if (run['status']!='NOT RUN' or run['installation_confirmed'] is not False or
        run['workflow_state']!='WAITING_FOR_INSTALLATION_AND_EXPLICIT_FRESH_CHAT_RERUN_REQUEST' or
        run['auto_start'] is not False or run['fresh_chat_rerun_requested'] is not False or
        run['actual_outputs'] or run['run_id'] is not None):
        raise ValidationError('Unexpected claimed interactive execution/installation')
    return dict(status='PASS_DOCUMENT_INTEGRITY_ONLY',package_id=manifest.get('package_id'),
                files_verified=len(files),source_modules_preserved=count,source_blocks_preserved=blocks,
                previous_candidate_zip_exact=True,statement_of_faith_exact=True,
                preserved_test_definitions=86,prior_D02_test_definitions=72,prior_DEC09_test_definitions=12,new_D04_test_definitions=5,total_test_definitions=175,
                instruction_characters=len(instructions),instruction_CRLF_characters=len(instructions)+instructions.count('\n'),
                prior_D02_001_conversation='FAIL_OWNER_REPORTED_DRAFT_0_3',current_candidate_execution='NOT RUN',
                real_application_test_status='NOT RUN',production_authorized=False,
                note='Document verification only. No correction behavior or application test was executed; no deployment, legal/security certification or rights clearance.')

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('package',type=Path,nargs='?',default=Path('.'))
    args=ap.parse_args()
    try:
        result=validate(args.package)
    except (ValidationError,OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
        print(json.dumps({'status':'FAIL_DOCUMENT_VALIDATION','error':str(exc)},indent=2))
        return 1
    print(json.dumps(result,indent=2))
    return 0

if __name__=='__main__':
    sys.exit(main())
