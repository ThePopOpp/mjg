# Draft 0.4 candidate release notes

SV2-DOCSET-D0.4-20260926; CHG-D02-001-001; September 26, 2026 (America/Phoenix). Targeted D02-001 onboarding/simulation correction. Prior Draft 0.3 owner-reported conversational FAIL preserved; no full transcript or real application failure asserted. New five D04 regressions and corrected rerun NOT RUN.

Updates: current onboarding clauses; external controller-event boundary; S00/AG01–03 extracts and registry; test definitions/evidence; compact C1-derived C2 instructions (7409 characters including LF/spaces); nonautomatic fresh-chat handoff; source/package metadata and manifests. Exact previous ZIP, C1, twelve inputs, historical modules, faith and unrelated approvals preserved. No deployment, legal clearance, live billing, implementation or behavioral pass.
