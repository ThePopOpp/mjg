# Steward Complete Project Package — Draft 0.4

Package SV2-DOCSET-D0.4-20260926. Targeted CHG-D02-001-001, using compact C1-derived C2. Internal Steward V2.0; eventual Steward V1.0 — Initial Full Build. Development candidate only.

## Exact installation

1. Extract this ZIP and open Steward_Project_Draft_0_4. Keep Draft 0.3 unchanged; an exact copy is also at ARCHIVE/Draft_0_3_Previous_Candidate.zip.
2. In the development project's active files, remove/replace the old twelve masters. Upload exactly the twelve files inside this candidate's PROJECT_SOURCES, retaining their filenames: 00_Control_Register.md; 02_Framework_Blueprint_Assessments.md; 03_Conversation_Sensitive_Safety.md; 04_Product_Journey_New_Features.md; 05_Data_Privacy_Security.md; 06_Safety_Support_Release.md; 07_Commerce_Scripture_Rights.md; 08_Engineering_Experience_Operations.md; 09_Test_Suite_Quality_Control.md; 10_Teaching_Reference_Library.md; 11_Change_Impact_Decisions.md; Statement-of-Faith.txt. There is no numbered 01 file. Do not leave old duplicate active masters.
3. Open PROJECT_INSTRUCTIONS.txt and replace the entire project instruction field with its contents; do not append it to old instructions. Confirm the heading is DRAFT 0.4 / COMPACT C2. It is **7,409 characters including spaces and LF line breaks**, below 8,000; the CRLF count is 7,441. Save the setting. Do not restore the old oversized Draft 0.3 instruction file.
4. Keep ARCHIVE, REFERENCE, AGENT_PROMPTS, CONFIG, EVIDENCE, TESTING and release templates out of the active twelve-source set. They support review/engineering and are not additional governing project sources or production prompts.
5. Optionally paste CONTINUE_IN_NEW_PROJECT.txt for an installation/readiness check. It explicitly keeps development mode and starts no test.
6. When ready to rerun, open a **fresh test chat** in the corrected project and paste the request in TESTING/FRESH_CHAT_RERUN_PROMPT.txt. Mike supplies participant choices and separate TEST CONTROLLER EVENT confirmations. No rerun begins automatically after installation.

## What is corrected

Read OWNER_REVIEW.md and master09 Q07/Q08. Steward must wait for actual fictional choices and externally supplied scoped confirmations; it must not invent registration, verification, acknowledgment, MFA, access or save success. Current commercial decisions, including CHG-DEC09-001, are unchanged. The prior D02-001 conversational FAIL is retained as an owner report; no missing transcript is reconstructed. All 175 Draft 0.4 executions, including the five new regressions, remain NOT RUN. Actual application authentication, grants and persistence remain NOT RUN.

## Integrity and limits

Run `python TOOLS/validate_package.py .` from this folder, or pass the ZIP path. Documentation checks cover bytes, structure, preservation and instruction length only, not correction behavior or application testing. This candidate does not implement a harness, deploy, install itself, grant legal clearance or authorize live billing.
