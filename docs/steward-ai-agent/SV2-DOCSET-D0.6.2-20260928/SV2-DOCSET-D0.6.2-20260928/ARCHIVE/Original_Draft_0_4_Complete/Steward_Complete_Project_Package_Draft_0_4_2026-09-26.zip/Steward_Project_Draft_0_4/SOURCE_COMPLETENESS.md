# Draft 0.4 source acceptance and preservation

All twelve supplied Draft 0.3 attachments match the previously generated full candidate's PROJECT_SOURCES exactly. The exact Statement of Faith hash is b587d8af30ad22d695e48d78608cc6cbbf05d928cd3c6527c58ca305ac9e4e87. All 29 historical source bodies and 7,683 source blocks are preserved. The previous Draft 0.3 ZIP is archived unchanged, SHA-256 c2ee1439331f222c9691bd3b1c993db977b0fc0feff4893567cacce321ac1a95. Draft 0.1/0.2 archives and six native originals remain untouched.

Compact C1 was separately located as PROJECT_INSTRUCTIONS_Draft_0_3_Under_8000.txt, read and archived unchanged; SHA-256 4bc8d3cbfea8e908d0c2b5e4d3d2b9d15891146255b25d9c0d3e3e3625515a55. Compact C2 derives from it. Prior C1 use in the failed execution is unknown; the supplied report does not include the exact prompt/model or full transcript. The reported conversational FAIL is preserved separately from unrun Draft 0.4 correction and real application evidence.

No new native-original/visual audit, provider verification, rights clearance or application execution is claimed. Prior original-handoff history and text-only provenance remain recorded in the preserved candidates. Counts/hashes establish document preservation, not behavior or release approval.
