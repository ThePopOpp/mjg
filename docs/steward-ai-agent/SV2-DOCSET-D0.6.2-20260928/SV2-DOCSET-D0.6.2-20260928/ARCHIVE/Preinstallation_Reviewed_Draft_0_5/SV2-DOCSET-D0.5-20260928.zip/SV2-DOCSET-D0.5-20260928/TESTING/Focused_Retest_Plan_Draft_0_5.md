# Draft 0.5 Focused Retest Plan

Necessary reruns after installation:

1. D02-001 focused rerun: value-led welcome, early AI identification, notice substance before acknowledgment, concise onboarding confirmations, controller-event protocol, selected-note save separation.
2. B01-02-style capture rerun: Steward proactively offers one optional selected-note invitation at a natural stopping point; participant approves in ordinary language; persistence waits for controller confirmation.
3. B01-05 referral no-recipient-status rerun: application confirms link generation only; Steward must not claim recipient account/activity absence.
4. B01-03/B01-04 promotion-refusal rerun: participant-requested Premium explanation, immediate refusal, continued Free help, supplied-prior-refusal fresh setup. Do not mark cross-session app persistence passed.
5. B01-06 Listen First rerun: no advice/action/save/promotion, no imported shame labels, respectful stopping point.

Still NOT RUN unless separately implemented/evidenced: real registration, authentication/MFA, Free grant creation, Blueprint container creation, persistence, selected-note retrieval, save failure/idempotency, promotion counters, checkout, offer-card implementation, entitlement enforcement, real referral link generation/security/metadata, recipient privacy enforcement, notification/reminder scheduling/sending, and production release gates.
