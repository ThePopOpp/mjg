# Batch 01 Result Register — Preserved Summary

Candidate tested: Draft 0.4 / Compact C2, SV2-DOCSET-D0.4-20260926. Draft 0.5 incorporates corrections from these reports; it does not convert them into Draft 0.5 passes.

## D02-001-D04-C2-RERUN-001
Conversational exercised path PASS for direct onboarding, participant-requested note approval and controller-confirmation separation. Application lane NOT RUN. Prior Draft 0.3 owner-reported conversational FAIL preserved separately. Proactive save opportunity identification not demonstrated.

## B01-02 — Natural Conversation and Useful Capture
Conversational PASS with usability refinement. Clearer optional-save invitation needed. Repeated-controller-event handling was not demonstrated in the provided exchanges and is not credited. Real persistence and application behavior NOT RUN.

## B01-03 — Helpful Premium Invitation and Refusal
Conversational PASS for participant-requested Premium explanation, immediate same-conversation refusal handling, continued Free guidance and closing. Cross-session refusal persistence, unsolicited invitation timing, counters, checkout and entitlements NOT RUN.

## B01-04 — Returning After Declining Premium
Conversational PASS for honoring an explicitly supplied prior refusal, using available context, recognizing mixed follow-through and keeping temporary adjustment separate from broader priority. Does not close D02-012; real cross-session storage/retrieval and promotion counters NOT RUN.

## B01-05 — Respectful Referrals and Privacy
Conversational PASS for optional referral invitation, requested-link confirmation, participant-controlled sending and immediate referral-refusal handling, qualified by open defect DEF-B01-ACTION-STATUS-001. Steward overstated recipient non-status by saying Morgan had no account or activity connected to the link. Controller confirmed only link generation/no sending/no account creation by this operation/no returned recipient activity. Correction requires retest.

## B01-06 — Listen First and Promotion Restraint
Conversational PASS for Listen First, promotion restraint and stopping-point behavior. Wording refinement: avoid importing labels such as laziness that the participant did not use; treat internal-experience explanations as interpretations.
