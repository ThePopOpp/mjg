# Draft 0.5 Installation Instructions

1. Create or update a private Steward project for this candidate.
2. Upload only the twelve files in `PROJECT_SOURCES` as active review sources. Do not upload archived Draft 0.3/0.4 duplicates as competing authorities.
3. Put the full contents of `PROJECT_INSTRUCTIONS.txt` into the project instruction field.
4. Keep companion files (`EVIDENCE`, `MANIFESTS`, `AGENT_PROMPTS`, `CONFIG`, `TESTING`, `OVERVIEW`) as documentation/handoff artifacts, not active governing masters unless Mike explicitly selects them for a specific review.
5. Installation does not start testing. Return to development mode until Mike explicitly requests a focused Draft 0.5 retest.
6. No production release, live billing, real participant processing, legal clearance, rights clearance or application behavior is authorized by installing this package.
