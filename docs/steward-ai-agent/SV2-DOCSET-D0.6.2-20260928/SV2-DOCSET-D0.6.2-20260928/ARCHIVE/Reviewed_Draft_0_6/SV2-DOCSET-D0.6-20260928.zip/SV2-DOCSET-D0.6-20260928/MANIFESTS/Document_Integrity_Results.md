# Document Integrity Results — Draft 0.6

Package: SV2-DOCSET-D0.6-20260928

- Active PROJECT_SOURCES count: 12
- Numbered 01 source: intentionally absent
- Statement-of-Faith unchanged from archived Draft 0.4 active source: True
- BEGIN_SOURCE counts match archived Draft 0.4 active sources: True
- Source bodies from first BEGIN_SOURCE match archived Draft 0.4 active sources: True
- `<a id=>` source block total across active Markdown sources: 7683
- Test catalogue IDs retained in `TESTING/Test_Catalogue_175_Current_IDs.json`: 175 expected; see file.
- PROJECT_INSTRUCTIONS LF count: 6205
- PROJECT_INSTRUCTIONS CRLF count: 6227
- PROJECT_INSTRUCTIONS under 8,000: LF=True, CRLF=True
- Model-test runner available during package construction: no
- Acceptance script execution status: NOT RUN

Limitations: the complete standalone Draft 0.4 ZIP was not available in this workspace. Draft 0.6 carries forward available companions and identifies unavailable originals in SOURCE_COMPLETENESS.md.
