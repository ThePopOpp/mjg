# STEWARD — SV2-DOCSET-D0.6-20260928

Draft 0.6 / Compact C4 is a frozen engineering-handoff candidate for **Steward V1.0 — Initial Full Build**. It incorporates CHG-B02-FREE-SCOPE-EVIDENCE-001 on top of Draft 0.5.1 and preserves Draft 0.4/Draft 0.5/Draft 0.5.1 history where available.

This is not production authorization, live billing authorization, legal clearance, or behavioral/application test passage. The active install set is the twelve files under `PROJECT_SOURCES/` plus `PROJECT_INSTRUCTIONS.txt`.

Key additions:
- Free/Premium service-boundary correction.
- Controller-event evidence-label correction.
- Risk-based manual acceptance scripts under `ACCEPTANCE_SCRIPTS/`.
- Feature-to-requirement/test coverage map under `COVERAGE/`.
- Readiness report under `READINESS/`.

No isolated model-test runner was available during package construction, so all included acceptance scripts are NOT RUN until an authorized tester executes them.
