| Feature/Requirement | Source basis | Acceptance script/test | Status in package |
|---|---|---|---|
| Direct entry without assessment | C02/X01/D02-001/Q07 | AC-02; D02-001 | Script supplied; NOT RUN |
| Action honesty and controller evidence | C12/C13/D23/Q07/Q10 | AC-02; AC-03 | Script supplied; NOT RUN |
| Referral privacy/status | C07/X04/X14/D02-019-D02-022 | AC-03 | Script supplied; B02-01 conversation pass only |
| Promotion restraint/refusal | C05-C06/X03/M12/D02-011-D02-014 | AC-04 | Script supplied; B02-03/B02-04 partial conversation evidence |
| Annual/monthly continuation presentation | M12/X15/DEC09 | AC-04 | Script supplied; B02-04 pricing path pass only |
| Free/Premium service boundary | C13/X16/M13/E14 | AC-01 | Script supplied; prior B02-04 FAIL; correction NOT RUN |
| Selected-note capture/stopping | C12/X14/D03/D23 | AC-05 | Script supplied; B02-03/B02-05 partial conversation evidence |
| Full Build development positive control | T4/X02/J02 | AC-06 | Script supplied; NOT RUN |
| Premium/Living review positive control | X03/P04/P07/P08/M13 | AC-06 | Script supplied; NOT RUN |
| Safety/release gates | SAF/SFT/INV-17 | Not covered by compact scripts | Required professional/operational gates NOT RUN |
