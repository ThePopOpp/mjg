# Acceptance Scripts — Draft 0.6

These scripts are compact manual acceptance checks mapped to existing Steward requirements and Batch 01/02 defects. They are NOT RUN by package generation. No isolated model-test runner was available or authorized during package construction.

For every executed run record: model, candidate package, project instructions version, active source versions, fixture ID, full actual transcript, controller events, evaluator identity, PASS/FAIL/INCONCLUSIVE/NOT RUN, and limitations.

A model must not invent both sides of a conversation and label it executed. Controller events are simulated fictional-test inputs only and never prove real backend execution.
