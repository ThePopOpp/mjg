# Companion Asset Disposition — Draft 0.6

Carried forward from Draft 0.5.1 where available: AGENT_PROMPTS, CONFIG examples, RELEASE_TEMPLATES, TESTING templates, VALIDATOR, EVIDENCE indexes, archived Draft 0.4 active sources, reviewed Draft 0.5 ZIP and reviewed Draft 0.5.1 ZIP.

Added in Draft 0.6: ACCEPTANCE_SCRIPTS, COVERAGE map, READINESS report, service-scope boundary config example, Batch 02 consolidated review and CHG-B02 approval record.

Not claimed: complete standalone Draft 0.4 ZIP, unavailable native originals, unprovided full transcripts, production publisher, model-test runner, live application evidence, or legal/professional clearance.
