# Steward V2.0 D0.7.2 — Independent Engineering Handoff Audit

**Review date:** November 11, 2026  
**Candidate:** `SV2-JEREMY-PROPOSED-D0.7.2-20261111`  
**Reviewed artifact:** `Steward_V2_D0.7.2_Complete_Engineering_OWNER_REVIEW.zip`  
**Disposition:** **GOOD FOR A LIMITED JEREMY ENGINEERING DISCOVERY/INVENTORY REVIEW WITH AN EXPLICIT DRAFT LABEL; HOLD AS THE ONE FINAL AUTHORITATIVE BUILD BASELINE UNTIL THE NARROW CORRECTIONS BELOW.** This is not production-release approval.

## 1. Verified improvements

- ZIP extraction and CRC/integrity test passed. **74 files**, including **73 payload files**; every payload file matched the path, byte count, and SHA-256 in `FINAL_PACKAGE_MANIFEST.json`; no unlisted payload files.
- The original twelve Draft D0.6.2 source files are byte-identical to those included in D0.7.1 (sampled hashes for critical baseline files; full D0.7.2 baseline hash manifest is internally consistent). Each of the eleven proposed revised masters contains the original respective baseline as an exact unchanged byte sequence. The proposed Statement of Faith is also exact unchanged bytes (SHA-256 `b587d8af30ad22d695e48d78608cc6cbbf05d928cd3c6527c58ca305ac9e4e87`).
- 43 distinct feature IDs (`V2-F001` through `V2-F043`); original P01–P15 / S01–S12 names are retained as historical. **160 unique test rows**, all marked `NOT RUN` for both conversation and application. Counts by fixture readiness: **131 specification-only**, **10 harness-assertion-ready**, **19 synthetic-scenario-ready/not executed**.
- The unified public strategy is substantively present: one Created for More and Free Steward experience for public/Compass-referred visitors; no Compass-specific prompt or automatic Premium, church affiliation optional, public Free/Full/Premium flow and consent-conscious attribution. Church/ForgedLife work is correctly placed in an independent gated stream.
- The 30-day eligible Free-to-Premium cohort definition distinguishes paid checkout from verified purchase, Full-only from Premium, matured from incomplete cohorts, and participant value from conversion metrics.
- Public rollout is not falsely treated as automatically authorized: retained invitation-only/Arizona-first pilot and safety/privacy/rights/billing gates are expressly flagged for formal transition review.

## 2. Corrections required before final authoritative engineering handoff

### BLOCKER A — Original October Annual Retreat sources not incorporated

`SOURCE_GAPS/October_Retreat_Source_Reconciliation.md` still says the originals are unavailable. The exact originals have been recovered and are attached in this audit supplement, including:

1. `Annual_Stewardship_Blueprint_Retreat_Guide_v2_Scripture_Review.pdf` (48-page source)
2. `CHG-V2-RETREAT-001_Source_Registration_and_Product_Direction.md`
3. `CHG-V2-RETREAT-002_Product_Funnel_Premium_Entitlement_Direction.md`
4. `RETF_Annual_Retreat_Funnel_Acceptance_Tests_NOT_RUN.md` (30 unique original RETF-01–RETF-30 definitions)

Reconcile these against RET01–RET11 and the newer approved product direction, preserving exact source/status/rights boundaries. In particular verify the full Free guide's standardized Energy Audit discrepancy, included personalized digital Premium benefit, discretionary five-email marketing consent, source-selected history, special printed journal limits and channel-specific Scripture rights. Do not blindly promote source candidates into governing/production-serving content. The original 30 RETF tests may be integrated with crosswalks, not silently replaced with eleven shorter tests.

### BLOCKER B — Feature ↔ test matrix remains inconsistent, including a substantive Year-in-Review gap

Normalized bidirectional test comparison of `MATRICES/Feature_Requirement_Test_Crosswalk.csv` against `TESTS/Acceptance_Test_Matrix.csv` finds **36 nonreciprocal feature/test relationships across 18 feature families** (**7** listed feature→test relationships missing their test-row backlink, **29** test→feature backlinks not reflected in the feature's declared test list). See `D072_Feature_Test_Traceability_Findings.csv` in the supplement.

Specific examples:
- `V2-F022` Year in Review / My Next Season claims RET04–RET08, but **none** of those test rows references F022. The RET tests mainly target Premium personalized retreat behavior and do **not** explicitly validate an annual narrative or transition-to-next-season decision. Add targeted Year-in-Review / next-season criteria and tests, rather than simply relabeling unrelated RET cases.
- `V2-F013` Enough → Freedom → Multiplication claims FIN01–FIN04, but FIN03 and FIN04 only link to other topics. Either narrow the listed tests or add true progression assertions.
- Cross-cutting public tests (`UNI01`,`UNI04`,`UNI07`,`UNI09`,`CV06`) have extra feature links in the test matrix not reflected back in the feature crosswalk.

Make one normalized mapping the source for all representations. A validation script must expand ranges including `REL-D072-01–03` and **fail** on both directions of inconsistency. The supplied `TESTS/check_d072_static.py` only verifies the five NEW D072 rows' listed test existence, not the existing 38 families or both directions.

### BLOCKER C — $299 package falsely labeled recurring

`EFFECTIVE_CURRENT_REQUIREMENTS.md` identifies `V2-F030` as **“Versioned checkout, $299 recurring, grants.”** The same feature label appears in `MATRICES/Feature_Requirement_Coverage.csv`, and `ENGINEERING/Universal_Public_Journey_and_Conversion_Contract.md` describes `$299 initial / $199 renewal terms` ambiguously. These conflict with the approved product distinction: **$299 initial Build + first year of Steward is prepaid and does NOT automatically renew**; $149 one-time Full Build, $19/month and $199/year ongoing offers have distinct approval/entitlement rules. Correct the label and explicit nonrenewing assent/activation logic in current-facing source and tests; no misleading recurring subscription or automatic renewal may be implemented.

### BLOCKER D — Fixture validator fails even though the D072 static checker passes

Executed from the actual ZIP:

- `python TESTS/check_d072_static.py` → `PASS` for its limited documented checks.
- `python TESTS/run_fixture_checks.py` → **fails** with `KeyError: 'id'` because the three new `D072_*.json` fixtures use `fixture_id`, while the inherited validator expects `id` and at least three assertions on every fixture.

Correct fixture schema or version the validators so that the intended full check runs successfully. The D072 public-parity fixture currently uses a **text placeholder** for its 28 ratings, not an executable answer set; bind a frozen CFM4 fixture and expected seven subscale totals. The D072 conversion fixture includes checkout-only, Full-only and out-of-window examples, but does **not** include the duplicate-webhook and refund cases claimed in `TESTS/D072_Public_Parity_Test_Protocol.md`. Supply those cases and expected results, or narrow the protocol claim. These are fixture/reporting errors; the broader AI/backend test suite still properly remains NOT RUN.

### CORRECTION E — Resolve direct-entry measurement contradiction

`ENGINEERING/Universal_Public_Journey_and_Conversion_Contract.md`, event `free_steward_first_conversation`, requires a response “following saved assessment-linked identity,” while the 30-day denominator and J-UNI-01 explicitly include eligible **direct-entry users who did not take an assessment**. Define the event to count any authorized verified user's first eligible Free Steward conversation and record assessment origin separately; do not make assessment completion an implicit prerequisite. Include a direct-entry test.

### CORRECTION F — Stale identifiers remain in current-facing files

Several nonhistorical current documents still identify the candidate as `SV2-JEREMY-PROPOSED-D0.7.0-20261111`, e.g. `ENGINEERING/Agent_and_Response_Instructions.md`, `ENGINEERING/Teaching_Retrieval_Specification.md`, `RELEASE/Release_Gates.md`, and `OWNER_REVIEW/Unresolved_Decisions.md`. Retain historical snapshots untouched, but identify all active build instructions with the final accepted candidate/version and link older provenance in history. `EFFECTIVE_CURRENT_REQUIREMENTS.md` must remain the controlling reading view.

## 3. Issues Jeremy can reasonably own after handoff (not reasons for another broad rewrite)

- Inventory actual code, deployed prompt/model, source chunks, databases/RLS, identity and recovery, checkout/entitlements, analytics, prior support settings, church/ForgedLife interfaces and active public access. Report a verified current-vs-target gap matrix; never infer implementation from documents.
- Turn specification-only tests into staged executable fixtures, including exact CFM4 7-layer and Energy Audit 4-energy mappings and negative outcomes. Run conversation, API/database, email-recovery, cross-account, billing, rights, and security regressions separately. **Unexecuted tests remain NOT RUN.**
- Build source/rights-reviewed teaching retrieval, actual 30-day cohort queries, privacy-safe event instrumentation, error handling, flags and rollback. Obtain independent privacy/security/legal/commercial/safeguarding/Scripture rights review where required.
- Obtain separate owner authorization for actual broad-public rollout transitioning from prior invitation-only Arizona-first controls. This is a release/operational gate—not a request to reverse the already chosen public-first product vision.

## 4. Recommended disposition

1. **Do not start another wholesale documentation rebuild.** Apply the six narrow corrections above and record source/test/candidate hashes in one final reviewed revision or controlled errata.
2. **Jeremy may begin a clearly labeled preliminary inventory and feasibility discussion now** if Mike authorizes it, using this D0.7.2 candidate with the audit attached. He should not treat D0.7.2 as the final binding implementation baseline until it is corrected and approved.
3. Once the narrow corrections are demonstrated, **accept the exact package for engineering**. Executed acceptance suites, vendor settings and specialist clearances belong to Jeremy's subsequent stage-gates before production deployment; they need not all be completed before assigning the build.

**Limitations:** This review checked the uploaded ZIP, byte contents, source preservation, filenames, manifest, matrices, testing scripts and synthetic fixtures, not actual Steward behavior, live website or provider configuration. Retrieved October sources were inspected as supplementary source inputs; the full 48-page workbook has not been editorially re-approved or cleared for publication in this review. No release or billing action is authorized by this audit.
