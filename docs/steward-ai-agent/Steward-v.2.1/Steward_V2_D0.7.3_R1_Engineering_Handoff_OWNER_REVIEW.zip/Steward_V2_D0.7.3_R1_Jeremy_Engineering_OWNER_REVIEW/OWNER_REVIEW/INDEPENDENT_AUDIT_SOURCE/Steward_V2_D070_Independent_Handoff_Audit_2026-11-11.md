# Steward V2.0 — Independent Handoff Audit

**Candidate reviewed:** `SV2-JEREMY-PROPOSED-D0.7.0-20261111`  
**Archive:** `Steward_V2_Complete_Jeremy_Handoff_OWNER_REVIEW_2026-11-11.zip`  
**Audit date:** November 11, 2026  
**Recommendation:** **HOLD as the final authoritative Jeremy handoff; acceptable for a clearly marked preliminary engineering gap review.** Do one focused reconciliation/correction revision, then obtain Mike's exact package approval and deliver it for engineering. Actual production approval remains separate.

## Verified

- The ZIP contains **45 files** and passes the ZIP CRC/integrity test.
- `FINAL_PACKAGE_MANIFEST.json` lists 44 other files and all listed sizes and SHA-256 hashes match the extracted bytes.
- The 11 `PROPOSED_MASTERS/*.md` documents each embed the corresponding `BASELINE_D0.6.2_UNCHANGED` Markdown text exactly, following a distinct proposed amendment at the top. The Statement of Faith is byte-identical between the baseline and proposed directories.
- There are **38** feature-family rows and **141 unique** rows in `TESTS/Acceptance_Test_Matrix.csv`. The test statuses are NOT RUN. Documentation is not application evidence.
- The full edited manuscript `TLYB Book First Edit.docx` opens successfully. It is a **first-edit** teaching source, not necessarily the latest owner-approved manuscript or a cleared production-serving edition.
- The package distinguishes legacy nonrenewing $299 agreements from the separately selected `CHG-DEC09-001` recurring $299 initial / $199 annual offer, subject to consent and release gates. Privacy, user control, Scripture rights and safety boundaries are generally carried forward.

## Correct before final owner acceptance

### 1. Critical: feature-ID collisions in the coverage matrix

The original `BASELINE_D0.6.2_UNCHANGED/04_Product_Journey_New_Features.md` reserves **P01–P15** and **S01–S12** for specific Premium/Season product directions. The new `MATRICES/Feature_Requirement_Coverage.csv` reuses several P IDs for different meanings. Examples:

| ID | Original Draft 0.6.2 | New feature coverage matrix |
|---|---|---|
| P08 | Vision Casting / My Next Season | Blueprint Version History and North Star visual |
| P09 | Blueprint Version History / My Blueprint Journey | Selected Progress Memory / Remember When |
| P11 | Remember When Moments | Current Season, area postures, capacity, evidence |
| P12 | Accomplishment & Progress Memory | Experiments / Protect / Re-engagement |
| P13 | Visual Steward Experience | Free/Full/Premium service boundaries |
| P14 | Multi-Channel Communication | Entry, signup, assessment optional |
| P15 | Inner Circle / Membership Benefits | Checkout, $299 recurring, grants |

**Required fix:** assign a unique new identifier scheme to all 38 proposed coverage rows (for example `V2F-001` through `V2F-038`); retain the original P and S identities **unchanged** and add columns mapping each new family to exact P/S/OD/CHG source IDs and appropriate sections. Update all 141 `feature_ids` references, test reports and engineering citations. Do not make Jeremy guess which `P13` is meant.

There is also a measurable reverse-traceability defect: the coverage row currently called `P07` (Year in Review / My Next Season) maps to RET04–RET08, but none of those test rows names `P07` in its own `feature_ids`. `R13` has a similar reverse-coverage mismatch on FIN03–FIN04. Reconcile feature-to-test mappings in both directions.

### 2. Missing October authoritative *source candidates* and detailed retreat tests

The ZIP lacks the actual later Annual Retreat materials known in the project/Library:

- `Annual_Stewardship_Blueprint_Retreat_Guide_v2_Scripture_Review.pdf` (48-page source template)
- `CHG-V2-RETREAT-001_Source_Registration_and_Product_Direction.md`
- `CHG-V2-RETREAT-002_Product_Funnel_Premium_Entitlement_Direction.md`
- `RETF_Annual_Retreat_Funnel_Acceptance_Tests_NOT_RUN.md` (30 additional defined cases)

The package only contains newer summaries and 11 broad RET01–RET11 scenarios. **Do not assume those eleven fully replace or satisfy the older 30-case retreat test specifications.** Import the original files as versioned, correctly classified reference/change/test inputs; compare their exact requirements against 02/04/05/07/08/09 and the full target. Specifically reconcile the **Free complete guide**, **included personalized Premium digital PDF without a separate PDF charge**, **print-only-as-optional-add-on**, **participant-specific privacy selection**, **NIV publication issue**, and relevant acquisition/consent details. Preserve the original documents' proposed/approved distinctions; do not promote a source-candidate automatically into runtime guidance.

Also register the November ForgedLife/Compass implementation correspondence or its approved sanitized interface contract, with consent mapping, event payload/version, ownership and source of truth. Do **not** place webhook secrets or other credentials in the ZIP.

### 3. Supply one *effective* requirement view after reconciliation

The 11 proposed masters each prepend a relatively short amendment and then repeat the full former baseline. This is useful for auditability but **not** a clean implementation or runtime source when old passages disagree with new target direction. Maintain these redline/audit versions, and also publish a generated, deduplicated effective-current requirements list, with: new requirement ID, source/section, authority, old requirement superseded, final normative wording, feature, acceptance tests, release scope and owner approval. Do not load the 12 full historical/review masters or duplicated manuscript into AI retrieval as interchangeable current instructions.

A workable implementation may use a concise current source router plus approved serving corpus, but it needs a definitive precedence/allowlist, not a developer's interpretation of layered historical prose.

### 4. Make critical acceptance tests executable, not merely descriptive

The 141 rows are valid **test ideas**, but several fixtures are textual labels rather than actual data. For example, AS01 says `Full synthetic 28-answer, 7-layer fixture` without an attached 28-value input and independently calculated expected section results; AS06 similarly calls for a 20-answer Energy Audit fixture without all its answers/expected totals. Add machine-readable synthetic fixtures, exact expected scores, dated/versioned payload examples, failed/unknown/retry conditions, example UI state, and (where applicable) before/after verbatim coaching transcripts. Define who runs/evaluates them and record actual results without fabricating PASS.

Confirm coverage for the original/retained security, privacy, commerce, safety, rights, STATE-001, D02-001, Batch 01/02 and 30-case retreat tests; the 141-row count is not by itself proof that all inherited tests are traced. Quality rubric's 14/16 target remains proposed until Mike explicitly accepts it.

### 5. Align near-term build sequencing with the January church experience

`RELEASE/Implementation_Phases.md` places **Church/ForgedLife** in Phase 5, after advanced Living/Retreat work in Phase 4. That may conflict with near-term Compass facilitator/study onboarding needs. Provide a separate **launch-critical dependency path** for safe participant enrollment, study discovery, organization-approved facilitators, ForgedLife consent/event handoff, assessment → results → Steward, joining materials and meaningful follow-up, with clear owner and staging acceptance. Advanced annual retreat and printed-journal features should not block that path unless their technical dependencies genuinely require it. No date is implied by the current documentation; obtain actual rollout milestones from Mike and Jeremy.

### 6. Define what “complete V2.0” means for deferred features

The package explicitly **defers or gates** named Accountability Partner Mode, Family/Spouse Conversation Mode, rich Life Story/Journal, some Remember When/photo capabilities, SMS/push and physical printing. That is sensible for privacy and scope, but `START_HERE_JEREMY.md` calls the assignment comprehensive. The owner review needs an explicit **build versus design-only versus later decision** column for each of the 38 families. Do not call an item fully specified if only its future intention and denial behavior are written. Never bypass the separate consent/rights/commerce gates merely to label V2 complete.

### 7. Resolve the duplicate manifests

`FINAL_PACKAGE_MANIFEST.json` is complete and passes independent verification, but the additional `MANIFEST.json` calls itself a 40-file snapshot and omits four later package additions (plus the manifests). Rename the older one as a dated intermediate assembly manifest or remove it from the final engineering package, leaving an unmistakable single authoritative integrity manifest. Preserve historical manifests separately if important for source provenance.

## Jeremy's first engineering deliverables (after owner approval)

The ZIP legitimately does **not** contain production code, live model/prompt and provider settings, databases/RLS, security credentials, or real application receipts. Jeremy must inspect those sources to develop the concrete implementation. Require a deployed-versus-target inventory, versioned code/prompt/source manifests, final request/response schemas and error states, role/permission matrix, threat/consent flow, migrations, staged flags and rollbacks, real score payload/recovery demonstration, quality-test harness, synthetic results/transcripts, latency/cost budget and independent release-gate evidence. The sample API paths in `ENGINEERING/Integration_and_Data_Contracts.md` are **illustrative**, not final code contracts.

For the central P0 teaching-quality problem, don't settle for “we uploaded the book.” Demonstrate two or more before/after responses: assessment first-response with seven actual CFM4 sections, distinct 4-category Energy Audit, participant-informed teaching with a relevant approved Blueprint principle/Scripture reference, correct why and a useful voluntary next step; plus a Listen First case that does not force advice. Verify retrieval source/version and prohibited excerpt behavior. Build/rights clearance of the curated serving corpus is a prerequisite for claims that the manuscript is operationally available to Steward.

## Decision recommendation

- **NO-GO** on this exact D0.7.0 ZIP as the *final authoritative* implementation package. Do not treat it as installed, approved for live use, or self-validating.
- **GO for a marked preliminary discovery review with Jeremy**, if Mike wishes, without authorizing development against ambiguous IDs or enabling new features.
- Request **one targeted D0.7.1 correction pass**, focused on the seven corrections above, not another wholesale rewrite of source history.
- Once Mike approves the exact revised ZIP, send to Jeremy for code inventory and staged engineering. Do **not** require the engineer to finish all application tests *before* receiving a build specification; actual tests and qualified reviews gate staging/production releases, not the initial engineering handoff.

**Audit method/limits:** inspected the uploaded ZIP, extracted all files safely, compared hashes and proposed/baseline source text, parsed CSV references, and reviewed engineering/release documents and the included first-edit manuscript. The external original September ZIP was not independently byte-compared because its Library version could not be materialized; the supplied baseline and proposed master text were verified against each other. No production code, real application requests, live deployment, legal rights, professional reviews or model behavior were executed by this audit.
