#!/usr/bin/env python3
"""D0.7.3 deterministic *documentation and fixture* checks; no model/backend execution."""
import csv,json,pathlib,sys,datetime
from collections import Counter
r=pathlib.Path(__file__).resolve().parent
f=list(csv.DictReader((r.parent/'MATRICES/Feature_Requirement_Coverage.csv').open(encoding='utf-8')))
t=list(csv.DictReader((r/'Acceptance_Test_Matrix.csv').open(encoding='utf-8')))
assert len({x['feature_id'] for x in f})==len(f)==43
assert all(x['conversation_status']=='NOT RUN' and x['application_status']=='NOT RUN' for x in t)
assert all(set(x['feature_ids'].split(';'))<={f['feature_id'] for f in f} for x in t)
n=0
for p in sorted((r/'fixtures').glob('*.json')):
 d=json.loads(p.read_text(encoding='utf-8'));assert d['id']==p.stem,(p,'id mismatch');assert len(d.get('assertions',[]))>=3,(p,'few assertions')
 if p.stem=='AS01':assert len(d['responses'])==28 and sum(d['responses'])==d['expected']['total']
 if p.stem=='AS02':assert len(d['responses'])==28 and d['responses'].count(None)==1
 if p.stem=='AS06':assert len(d['responses'])==20 and sum(d['responses'])==d['expected']['total']
 if p.stem=='D072_PUBLIC_PARITY':
  assert len(d['common']['answers'])==28 and sum(d['common']['answers'])==d['common']['expected_total']
  assert len(d['common']['expected_seven_layer_scores'])==7 and sum(d['common']['expected_seven_layer_scores'])==d['common']['expected_total']
  assert len(d['variants'])==2
 if p.stem=='D072_CONVERSION_COHORT':
  from datetime import datetime,timedelta,timezone
  dt=lambda x:datetime.fromisoformat(x.replace('Z','+00:00'))
  seen=set();matured=gross=net=0
  for x in d['participants']:
   assert x['id'] not in seen;seen.add(x['id'])
   start=dt(x['first_free']);end=start+timedelta(days=30)
   if end>dt(d['as_of']):continue
   matured+=1
   if x.get('purchase_verified') and x.get('product')=='premium' and start<=dt(x['purchase_verified'])<end:
    gross+=1;net+=not bool(x.get('refunded'))
  assert matured==d['expected_mature_verified_free_participants']
  assert gross==d['expected_premium_purchasers_in_30d']
  assert net==d['expected_net_nonrefunded_premium_purchasers_in_30d']
  assert gross/matured==d['expected_30d_conversion_rate']
 n+=1
print(f'PASS: {n} fixture schema/arithmetic checks; 43 feature IDs; {len(t)} test definitions all NOT RUN. Does NOT execute AI, application, or payment provider.')
