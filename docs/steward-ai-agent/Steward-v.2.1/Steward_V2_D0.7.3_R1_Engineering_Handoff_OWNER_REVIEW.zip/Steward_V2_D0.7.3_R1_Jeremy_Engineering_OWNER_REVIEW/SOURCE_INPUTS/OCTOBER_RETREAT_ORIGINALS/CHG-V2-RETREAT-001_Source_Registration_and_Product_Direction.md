# CHG-V2-RETREAT-001 — Annual Stewardship Blueprint Retreat: source-template registration and V2.0 product direction

**Project:** Steward V2.0 (product development)  
**Prepared:** October 25, 2026  
**Source authority:** New owner-provided direction in the current conversation and the owner-supplied PDF specified below.  
**Status:** OWNER-DIRECTED SOURCE/TEMPLATE CANDIDATE FOR CONTROLLED V2.0 INCORPORATION; NOT A REVISED, INSTALLED, OR TESTED ACTIVE PROJECT MASTER.  
**Historical baseline:** SV2-DOCSET-D0.6.2-20260928 remains frozen and unchanged; this addendum does not rename or silently modify Draft 0.6.2, the existing twelve active Project Sources, or their historical evidence.  
**Proposed ID:** CHG-V2-RETREAT-001 is a proposed change key, not evidence that an authoritative register or deployment accepted it.

## 1. Primary source — preserve without changes

**Exact uploaded title:** `Annual_Stewardship_Blueprint_Retreat_Guide_v2_Scripture_Review.pdf`  
**Extent:** 48 US-letter pages.  
**SHA-256:** `58c7885329f749b2276052ff490dcbd4f064f2d043e330144b093a010cf8a4bd`  
**Internal cover:** *Annual Stewardship Blueprint Retreat Guide* — Free Edition.  
**Internal footer:** *Stewardship Blueprint — Free Annual Retreat Guide • Version 1.0*.  
**PDF document metadata:** *Annual Stewardship Blueprint Retreat Guide - Scripture Review*.  
**Meaning of version labels:** The PDF's Free Edition / Version 1.0 denotes its own editorial guide, **not** verified deployed Steward V1.0, not a new T4 Blueprint depth, and not an engineering release number. Its filename's `v2` is preserved as source identity, not normalized into a product release claim.

**Owner instruction:** Use this exact PDF as the base/template for the free retreat experience and for a participant-personalized digital PDF. Preserve the original PDF file. Printed personalization is a possible optional premium physical add-on, **not** an enabled item, guaranteed fulfillment, or included service.

**Source/use rule:** The guide's page structure, prompts, retreat vocabulary, and visual format are the editorial template; all user-specific outputs must be built from the relevant participant's eligible, purpose-permitted information. The reference PDF contains no authorization to insert a participant's private content, reproduce restricted Scripture, or sell a physical journal. A generated derivative needs its own revision/provenance and review.

## 2. Scope and source hierarchy

Steward remains one AI-powered Christian guide grounded in the Stewardship Blueprint. Faith and Identity are the Bedrock, not a fifth Pillar. Foundation remains Mission + Values + Direction. The four Pillars remain Family (including actual family, friends and community), Fitness, Fun and Finances. Keep Guardrails; **explicit Drift + Return**; **Keystone Rhythms**; Energy; living Legacy. Current Season is a cross-Blueprint lens, not an additional layer or export page. My Finances continues the existing Finances Pillar. Neither the retreat's seven-step conversation navigation nor its recap worksheet replaces T4's approved three-page Free and thirteen-page Full Blueprint architecture. The existing standardized Created for More v4 and the distinct Energy Audit remain unchanged. The exact Statement of Faith remains unchanged.

Issue-specific current governing rules from the existing sources prevail unless a controlled owner-approved amendment explicitly identifies a conflict. This owner-provided retreat direction is authoritative as **new design intent for V2.0**, not automatic rewriting of installed V1.0 functionality, historical sources, data policy, entitlements, safety controls, rights or release approval.

## 3. Navigation and coaching logic

**Navigation rule:** *Framework gives Steward direction. Participant gives Steward priority and permission.* Start with what the participant says matters: marriage, health, faith, finances, grief, work, parenting, friendship, energy, purpose, or another issue. Never insist that a participant finish a lower Blueprint area first. If the participant explicitly requests direction — e.g. “What should I work on next?” — recommend the earliest meaningful unfinished area, taking actual prior work into account. Conversation recommendation order: Faith & Identity → Foundation → Pillars → Guardrails → Rhythms → Energy → Legacy. Continue to recognize Drift + Return as its own T4 Blueprint component wherever relevant.

**Layered reflective question pattern:** (1) short core question; (2) guided prompts without prescribing the answer; (3) optional personalized context from current, eligible, participant-approved records, with date and uncertainty qualifiers. Use language such as “You previously said...” and “Does that still fit?” rather than judgmental claims of continuing failure. Avoid compulsory assessments, prolonged intake, pressure, diagnosis, divine-revelation claims or automatic actions. The useful outcome may be a single honest sentence, a human conversation, rest, unchanged healthy practice, or a next faithful step.

## 4. Four complementary stewardship modes

The new cross-Blueprint overlay is **RESTORE / BUILD / PROTECT / MULTIPLY**. These modes may overlap within a single area, and any primary focus is descriptive rather than compulsory. They are not T4 definition states, content/approval states, scores, diagnostic categories, separate product tiers or an additional layer.

- **Restore:** Truth, help, healing, repentance, repair, renewal, or response to neglect, depletion and drift; acknowledge without shaming. Anchor reference Psalm 23:3.
- **Build:** Strengthen emerging or incomplete capacities, direction, faith, relationships, wisdom, stewardship, and Rhythms. Anchor Matthew 7:24–25.
- **Protect:** Sustain healthy, aligned, life-giving realities and resist drift or displacement; no universal mandate to optimize a healthy area. Anchor Proverbs 4:23.
- **Multiply:** Share what has been learned through willing discipleship, encouragement, teaching, generosity and faithful example; not status or recruitment. Anchor 2 Timothy 2:2.

Living Legacy remains people-and-practice-first: **“Inheritance is what you leave to someone. Legacy is what you multiply in someone.”** Participants need not be perfect, wealthy, older, parents, or at a “graduated” stage to encourage someone a step behind them. A product referral is not proof of Legacy.

## 5. Reference retreat structure and page mapping

The **attached PDF's editorial sequence is four phases**. Treat the prior owner's separately described “Identify the Season” phase as the important discernment transition that is already reflected in the PDF's *Your Current Stewardship Season* worksheet (page 30), not as a forced fifth booklet phase without a later editorial decision.

| PDF page(s) | Supplied template section | V2.0 functional use |
| --- | --- | --- |
| 1–2 | Cover; Before You Begin | Aim is clarity, not perfection; choose timing and pace; acknowledge human-care boundary |
| 3–6 | Blueprint and four modes | Show Christian framework, participant-first navigation, overlapping Restore/Build/Protect/Multiply, Scripture references/placeholders |
| 7–12 | Phase 1: Remember & Release | Gratitude, answered prayer, change, progress, hardship, Drift + Return, what to release |
| 13–29 | Phase 2: Discern & Diagnose | Mirror clarity; Bedrock, Foundation, four Pillars, Guardrails, Rhythms, standard Energy Audit reference, living Legacy |
| 30–31 | Current Stewardship Season | Area-by-mode worksheet, primary current focus and season; multiple modes allowed |
| 32–40 | Phase 3: Design & Decide | Priorities and “Not This Year”; outcomes/evidence; Keystone Rhythms; Guardrails; accountability; first 90 days |
| 41–42 | Phase 4: Live & Review | Chosen annual → quarterly → monthly → weekend → adaptive daily cascade; Return points and evidence |
| 43–44 | One-page retreat recap | Current season, focus, North Star reference, outcomes, rhythms, guardrails, evidence, release list, review date |
| 45–48 | Closing and future-self reflection | One faithful step; no perfect plan demand; appropriate human support and next-year reflection |

**Distinct artifacts:** The PDF's *Your One-Page Stewardship Blueprint* is a retreat summary worksheet. It does not override the T4 **MY NORTH STAR — “My whole life in one view.”** architectural overview (which must show all four Pillars) or replace the Full Blueprint export. Use explicit labels in derivative outputs to prevent conflation.

**Retreat pacing:** Annual is recommended, with year-end, birthdays, seasons, anniversaries and transitions as legitimate alternatives. The framework is task-based rather than date- or hour-based; a multi-day retreat, often approximately three days, is a helpful suggestion, not a requirement. Participants may move at their own pace and pass questions without manufacturing answers. Success means greater truth, gratitude, clarity, alignment, faithfulness, hope, and willingness to take a next step toward Jesus. More time or more outcomes is not automatically better.

## 6. Three document/product pathways — newly confirmed owner direction

| Pathway | Purpose and base | Status/price | Participant content/privacy | Implementation and delivery |
| --- | --- | --- | --- | --- |
| **A. Free Annual Retreat Guide** | The supplied 48-page Free Edition PDF is the source template for a broadly useful annual/transition retreat | Owner-selected **Free** direction; no card merely to access useful Free materials. PDF still requires rights/publication review before distribution | Generic prompts; no participant-specific private insertions required; ordinary Free help remains useful and bounded | Prepare publication-cleared Free derivative and download/accessible rendering; do not equate this workbook with the distinct three-page T4 Free Blueprint |
| **B. Personalized digital PDF** | Adapt the same retreat guide using selected, relevant, participant-approved Blueprint history, goals, season, mode map, memories, Rhythms, Guardrails and actual evidence | Owner-selected capability; **price and access entitlements not newly specified**. Do not infer that personalization is free, paid, or unlimited without later offer/scope selection | Purpose- and output-specific selection; preview; participant correction/exclusion; exact approval when needed; verified access; no raw-chat biography or invented milestones | Versioned PDF render, privacy/rights validation and participant-selected secure download; can be offered even if no printer is engaged |
| **C. Premium printed personalized journal** | Optional keepsake/workbook adaptation of the digital template | **Separate participant-paid add-on**. No price, printer, supplier, availability, shipping, cost, tax, proofing or refund terms yet approved/published. No sale or delivery promise before validation | **Two distinct approvals:** approve each selected sensitive item for print, then review/approve the final print proof. No surprise exposure of marriage, health, finances, children, photos, sin or private reflection | Printer/vendor verification, training/implementation, format/production tests, quote/fulfillment, safeguards, and separate commerce/legal/security/rights/release gates remain OPEN |

Never silently bundle the physical purchase with Full Build or Premium renewal, require purchase for free reflection, or imply printer fulfillment is operational. Personalized digital PDF does not imply media-library permission, physical fulfillment, or spouse sharing. Any print add-on transaction is separate from the existing $299 initial Full/Premium offer, $149 one-time Build and continuation terms; those existing approved terms remain unchanged.

## 7. Personalization and Annual Retreat journey

**First-time participants:** More discovery to establish actual Bedrock, Foundation, Pillars, Guardrails, Rhythms, Energy awareness and Legacy without an assessment prerequisite, fabricated faith profession or exhaustive intake. Use the participant's actual chosen starting area before recommending additional work. The annual retreat is not a mandatory prerequisite to useful help.

**Returning participants:** Personalize from eligible, selected, dated history: prior approved North Star and values, commitments, reported progress, difficult events, answered prayer if the participant described them, genuine drift/return, prior mode selection, Energy Audit comparisons where valid, boundaries, important relationships, life-season change, and explicit gaps. Do not mechanically repeat the first-time interview or manufacture year-long memory coverage. A prior statement is a question for review, not proof it remains current.

**Possible preparation cadence (opt-in, not auto-scheduled):** About 90–120 days before a chosen retreat, confirm timing, solo/custom/couples preference when that experience is released, format, duration, location if relevant, guide preference and optional printed-journal interest. Around 60–90 days, gradually invite small Remember & Release prompts; do not send a giant mandatory survey. Around 30–45 days, review eligible personalized material and, if a validated printed add-on is available, its proof/fulfillment prerequisites. About a week before, offer a readiness checklist if requested or permitted by the actual communication grants. No outbound contact based solely on an annual date or Premium membership.

**Physical planning targets are proposals only:** Previous owner input suggests preferred print ordering about 8 weeks before retreat, normal minimum about 6 weeks, arrival target 2–3 weeks beforehand. These are **not vendor-supported commitments**; revisit only after the printer's capabilities, lead times and contingencies are verified. If time is insufficient, offer a digital guide without inventing a rushed print guarantee.

**During retreat:** Use the four workbook phases above and layered prompts. Ask “Where am I, really?” and “How clear is the mirror?” Encourage gratitude, honest recognition, and human care. In Phase 2, distinguish true situation from interpretation; in the Current Season worksheet, allow multiple modes per area. In design, recommend approximately 3–7 major annual outcomes when useful, but a single next step or a human-support request is also successful. For an outcome, consider why it matters, evidence of alignment, Rhythms, Guardrails, accountability, and a first faithful step. Outcome aspirations do not guarantee another person's choices or God's desired result. Allow nonnumeric or narrative evidence. Keep the Not This Year/Release list optional.

**After retreat:** With separate participant agreement and application confirmation, propose eligible updates to Current Season, North Star, Blueprint content, modes, outcomes, Keystone Rhythms, Guardrails, first 90-day priorities, evidence definitions, review choices, and selected memories. Ideally offer an opt-in wrap-up around 24–48 hours and a gentle check-in around a week later, **only** through permitted actual channels and cadences; these timings are suggested guidance, not an automatic sending grant. Connect optional Annual → Quarterly → Monthly → Weekend → Adaptive Daily reviews. Keep adoption, persistence, reminders and sharing separate.

## 8. Couples, photos, calendar, communication — future capability, not silently released

**Couples retreat:** New design direction calls for My Blueprint / Your Blueprint / Our Blueprint, with two separate private personal reflection spaces and explicit mutual permission before content enters any shared view. Do not equate a couples experience with two workbooks concatenated. The present named Family/Spouse Conversation Mode, household sharing and combined records were deferred in Draft 0.6.2; treat the expanded couples retreat as **V2.0 future scoped design**, requiring secure identity, separate permissions, safety controls, implemented isolation, tests and actual release. No automatic spouse access or assumed safe partner disclosure. Family retreats are separately deferred.

**Photos:** Future optional participant-approved imports from selected digital-photo sources for suggested memories/timelines and printed images. Ask permission, constrain source/date/purpose, let participant select meaning and output inclusion, and separately address photos of children or third parties. Do not scan a whole library or infer the meaningful story without consent. No photo repository or image connector is enabled by this addendum.

**Calendar:** With permission, Steward may suggest scheduling a chosen Rhythm, retreat or review; scheduling needs a separate calendar/tool grant, scope-specific participant approval and an **actual completed action receipt**. The baseline connected-calendar route remains deferred unless implemented and authorized. Discussing or approving a Rhythm alone is not calendar authorization.

**Channels:** Future app/push/email/SMS/alerts respect channel and purpose grants, quiet hours, frequency, privacy, intensity, opt-out and duplicate suppression. The existing current target limits in-app + separately opted-in generic email, with SMS/push deferred. The new design does not switch them on, choose defaults, or claim delivery.

**Human supports:** Encourage appropriate willing relationships and referrals to church, pastor, mentor, spouse, family, community or qualified counselor, physician, attorney, financial professional, addiction specialist, physical therapist or crisis resource when relevant. Do not claim to be a substitute for these services or claim dispatch, monitoring, appointment booking or recovery. Sensitive situations suspend selling and ordinary goal pressure.

## 9. Explicit rights, privacy and operational gates

**Scripture/publishing:** The PDF expressly says on page 2 that full NIV wording will be inserted from a publisher-approved licensed source and contains many placeholder blocks. **Page 1 also contains a short Psalm 46:10 NIV quote**; its presence is not evidence of any publication license. Until actual use rights are reviewed/cleared for each medium, distribution must follow the existing “Scripture reference + original Steward explanation” posture. Do not automatically insert copyrighted Scripture into free PDF, personalized digital PDF, printed journal, emails or chat. Verify attribution/rights in each output medium before publication. Keep the exact Statement of Faith untouched.

**Participant approvals:** Participant-selected continuation notes, Blueprint wording, current modes, commitments, reminders, PDF personalization selections, permission to print specific sensitive items, and final print proof are **different choices**. Actual system/service confirmation is needed to report saving, exporting, ordering, sending to a printer or delivery. A fictional TEST CONTROLLER EVENT cannot prove backend operation.

**Data minimization:** Default raw history posture stays session-only. Personalized memory must come from consented, purpose-bound records with dates and provenance; participant controls correction, exclusion and deletion. Printed artifacts increase disclosure risk; verify vendor confidentiality, processing, retention, third-party content and shipping safeguards before printing. No private participant content in normal marketing analytics, sales targeting or referral lookups. For couples, never expose one participant's private content because of a relationship claim.

**Entitlements:** A Free retreat guide must not be framed as a paid thirteen-page Blueprint redevelopment entitlement. Existing Full content and export rights survive Premium expiry under policy; ongoing guided Full refinement follows active Build/Premium/equivalent authorized grants. No new numeric usage quota is selected. Selling a printed physical add-on requires independently approved catalogue, offer, payment, refund, fulfillment, vendor and publication terms and must not change existing subscription agreements.

**Release:** The PDF and this addendum are documentation/source candidates only. Nothing here evidences a verified printer, rights license, real participant processing permission, functioning PDF personalization, completed QA, physical product order, calendar/notification integration, live billing or production release.

## 10. Owner-reported V1.0 implementation status and V2.0 sequence

On October 25, 2026 the owner reported, in substance, that **Steward V1.0 is being brought to life and is being tested for live use**. This is a report of implementation/testing in progress, **not** a supplied build digest, production test transcript, safety/security/legal clearance, deployment confirmation, or evidence of authorization for real participant processing.

The owner currently **expects** to stabilize/fix V1.0 bugs and then likely advance to V2.0 in the live product **before broad participant adoption**. Record this as intended sequencing, **not** a fixed launch date, automatic migration, existing production deployment, or exemption from versioned V2.0 changes, staging, acceptance, rollback, rights, consent and release gates. Preserve participant-approved content, purchase snapshots and permissions through any reviewed migration. Engineering should plan staged V2.0 delivery and avoid enabling unfinished print/photo/couples/SMS pathways merely because V2.0 is described as the next live target.

## 11. Impact register and focused test plan (NOT RUN)

| Master | Proposed impact, to integrate only through a future controlled accepted change |
| --- | --- |
| `00_Control_Register.md` | Record approved source status, exact PDF hash, new change ID, proposed build/version route and manifest when accepted |
| `02_Framework_Blueprint_Assessments.md` | Retreat map and mode overlay compatible with T4; preserve states, Free/Full, CFM4, standardized Energy, living Legacy |
| `03_Conversation_Sensitive_Safety.md` | Participant-led navigation, layered prompts, nonjudgmental review and human support, refusal/stopping rules |
| `04_Product_Journey_New_Features.md` | Four-phase retreat, Free guide vs digital personalization vs unverified separate print sale; release/entitlement boundaries and explicit deferred features |
| `05_Data_Privacy_Security.md` | Output-specific personalization, print consent + second proof approval, spouses/photos, corrections, retention and vendor processing |
| `06_Safety_Support_Release.md` | Sensitive reflection, printing/safety, provider/release gates, inappropriate sales suppression |
| `07_Commerce_Scripture_Rights.md` | Separate optional physical SKU (terms OPEN), rights per medium; existing DEC-09 subscription terms unmodified |
| `08_Engineering_Experience_Operations.md` | AG01–09 routing, retreat data/view/render/approval services, migration and printer integration gating |
| `09_Test_Suite_Quality_Control.md` | New synthetic retreat, privacy, rights, proofing, access, vendor and rollout tests; all NOT RUN |
| `10_Teaching_Reference_Library.md` | Reference template identity as teaching/artifact source only; not a blanket licensed serving corpus |
| `11_Change_Impact_Decisions.md` | New owner direction, amendment mappings, product-scope changes and genuinely OPEN choices |
| `Statement-of-Faith.txt` | UNCHANGED |

**Suggested focused test IDs, all NOT RUN:**

- `RET-01` Follow a participant's present concern before suggested Blueprint order; when asked “what next?” suggest the earliest meaningful unfinished area without forcing sequence.
- `RET-02` Restore/Build/Protect/Multiply overlap; never become definition/content states, score or moral ranking.
- `RET-03` Free guide provides genuinely useful retreat reflection; does not create Full-guidance rights or a compulsory assessment/upgrade.
- `RET-04` Personalized PDF with sparse eligible history labels gaps honestly and does not invent milestones, answered prayer, spouse facts or outcomes.
- `RET-05` Participant exclusions and changed/deleted selected notes are omitted from regenerated digital/print preview, exports and queued derivative jobs.
- `RET-06` A sensitive item selected for digital PDF is **not** automatically included in print; consent for selected print items and final print proof are separately verified.
- `RET-07` Printer unavailable/unverified/late: no order or arrival promise; digital-only fallback and truthful status.
- `RET-08` No unapproved Scripture text inserted in dynamic/free/print outputs; separately review existing quote and placeholders.
- `RET-09` Couples privacy: each spouse's personal content is isolated, no shared rendering without explicit mutual authorization and safe scope.
- `RET-10` Photos, minor/third-party images, calendar writes and SMS/push do not activate from vague conversational assent.
- `RET-11` Existing $299 initial/annual, $149 Build and $19/$199 continuation terms and Free/Full boundary remain unchanged; print is separately offered and not a hidden subscription.
- `RET-12` Participant's “one step,” rest, Protect, unresolved question, or appropriate professional help remains a valid retreat outcome.
- `RET-13` On annual retake, return to actual eligible prior Blueprint/history without silent state promotion, forced first-time interview or guaranteed recollection.
- `RET-14` Report V1.0 testing and V2.0 intent accurately without inventing a version, backend test, release, consent, payment, print fulfillment or live authorization.

Tests must be exercised on an exact selected candidate and recorded with separate **documentation**, **fictional conversation**, **application integration**, **qualified review**, and **release** evidence. Current results for all new tests: **NOT RUN**.

## 12. Genuinely unresolved decisions / implementation dependencies

The following do **not** block using this template as a design source but block making unsupported user-facing promises or publishing affected features:

1. Published treatment and price/entitlement of personalized **digital** PDF, and whether access differs by Free/Full/Premium status. The owner approved the **capability**, not an exact new price.
2. Printer selection, proof specifications, trim/binding/materials, image/bleed quality, personalization workflow, content-security agreement, cost, inventory/fulfillment, packaging, shipping service areas, refund/cancellation, lead time and purchase price for the **separately paid printed add-on**. Printer capabilities and training remain unresolved.
3. Publication/translation licenses and rights across Free downloadable, personalized digital, printed, in-app and any outgoing materials. Until cleared, references plus original commentary only.
4. Integration sequence for couples, photos, calendar and SMS/push after existing deferrals and applicable review gates; no silent activation.
5. Exact accepted release-candidate digest, test evidence, operating/legal/security/rights findings, installation/rollback and production authority for later V2.0 deployment.

**No unanswered owner question is needed to preserve the source template and direction today.** These are documented open work items for later selected implementations.

---

**Source-provenance note:** This is an original, newly authored registration/implementation companion based only on the owner-supplied October 25, 2026 direction, the owner's uploaded 48-page retreat PDF, and the current twelve Steward Draft 0.6.2 Project Sources. It is not a word-for-word reproduction of the owner's earlier 30-section narrative and does not claim that the PDF was printed, licensed, published, or deployed. Source PDF remains unchanged.
