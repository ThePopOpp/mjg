# CHG-V2-RETREAT-002 — Annual Retreat Product, Funnel & Premium Entitlement Logic

**Project:** Steward V2.0 (development and controlled documentation)  
**Prepared:** October 25, 2026  
**Basis:** Owner-supplied 28-section directive, *“Steward V2.0 — Annual Stewardship Blueprint Retreat — Product, Funnel & Premium Entitlement Logic”*, in the current conversation; the separately supplied 30-section Annual Retreat / Core Operating Logic direction; and the original 48-page retreat-guide PDF.  
**Predecessor:** `CHG-V2-RETREAT-001_Source_Registration_and_Product_Direction.md` (preserved unchanged).  
**Frozen comparison baseline:** Draft 0.6.2 / `SV2-DOCSET-D0.6.2-20260928`, twelve active Project Sources (preserved unchanged).  
**Status:** NEW OWNER-DIRECTED V2.0 PRODUCT-SCOPE / DOCUMENTATION CANDIDATE. Not installed in governing Project Sources, not an executed test, not a deployed implementation, not a rights/license clearance, not a real participant release or live commerce authorization.  
**Purpose:** Record the new owner-selected free/public, personalized Premium, printed add-on, acquisition, annual-retention and marketing requirements in a controlled change, without re-authoring the prior retreat core logic or unilaterally promoting deferred integrations into live service.

## 1. Governing product principle and resolved decisions

> **Free = Here is the framework. Premium = Steward knows your approved story and builds this with you.**

The Annual Stewardship Blueprint Retreat is simultaneously (1) real Christian mission/free value, (2) an optional public acquisition entry point, and (3) an annual Premium retention/re-engagement benefit. None may diminish the others. The free guide is **not** a crippled demonstration. Its full framework is valuable without signup or payment; its public distribution conditions remain subject to the selected website flow and publication rights.

The **complete free retreat framework** and the **Premium personalized service** are different benefits, not competing Blueprint architectures. The free guide is not the three-page Free Personal Stewardship Blueprint export; it is a separate public 48-page editorial retreat workbook. Premium is **not** “the complete version.” Premium is **the personalized version**, drawing from records available under separate participant-approved purposes and service access. A Premium personalized digital Annual Retreat PDF is included in the eligible active Premium service—no separate per-PDF purchase is proposed. The physical `My Stewardship Year` journal is a **separate optional paid add-on**, limited initially to properly entitled Premium participants and disabled until actual print/commerce/rights/release verification.

| Item | Owner-provided selection | Boundary / evidence status |
| --- | --- | --- |
| Public free retreat | Offer the complete Annual Stewardship Blueprint Retreat Guide via MJG.com as a substantive free resource and natural entry point | Existing PDF is a Scripture-review **source template**; actual publication copy, hosting, and rights clearance not demonstrated |
| Free Steward assistance | Allow useful bounded question explanation, current-conversation context, mode identification, limited Rhythm/Guardrail drafting, Energy Audit explanation, and one next step | No comprehensive historical personalized package or serial thirteen-page Full redevelopment represented as Free; preserve ongoing Free usefulness |
| Premium personalized retreat | Include gradual preparation, eligible historical context, Year in Review, guided personal questions, annual/season analysis, approved Blueprint revision assistance, customized evidence, digital PDF and 90-day follow-through | Only confirmed active Premium/Living or precisely equivalent authorized grant; purpose-specific consent/retrieval; no invented participant history |
| Personalized digital PDF price | Included in eligible Premium; **no extra per-retreat PDF charge** | Exact release and usage/rendering limits not evidenced; public catalogue/entitlement claims only after implemented/released |
| Printed personalized journal | Optional one-of-one Premium-only paid add-on (at initial V2.0 launch); no non-subscriber single-order path selected | Suggested retail **$75–$150 is exploratory**, not an approved price, quote or payment link; printer, cost, terms and logistics unverified |
| Couples retreat | Record optional solo/spouse preference; `My Blueprint / Your Blueprint / Our Blueprint` is future-capable design | Named spouse-mode and sharing currently deferred; private spaces and independent account/consent mandatory; no combined access implemented |
| Photo/calendar integrations | Future permissioned helper capabilities | Not enabled by mention or preference; separate permission/tool/release evidence required |
| V1.0 to V2.0 transition | Owner reports V1.0 being implemented/tested; intends bug stabilization first and V2.0 rollout before broad participation | No verified build, shipped release, integration pass, or rollout date established by the report |

### 1.1 Do not reinterpret existing purchased terms

`CHG-DEC09-001` remains controlling for its selected $299 initial Full Build + first 12 months Premium and $199 annual renewal after explicit activation (plus applicable tax), as well as the separately eligible $149 one-time Build, $19 monthly or $199 annual continuation, and true legacy $299 nonrenewing contracts. This amendment does **not** add an initial-Full shortcut, a hidden recurring agreement, a mandatory print purchase, a Premium-only Scripture teaching gate, or a new price. Existing retained-Full viewing/export rights remain. An active Premium participant does not pay another initial Full fee because of an annual retreat. A separately purchased printed journal requires independent price/terms/payment assent and must not silently affect subscription renewal.

### 1.2 Four-phase retreat and full-framework integrity

The exact 48-page PDF stays the editorial source template: **Remember & Release → Discern & Diagnose → Design & Decide → Live & Review**, with a Current Stewardship Season worksheet within Discern & Diagnose. Cross-cutting **Restore / Build / Protect / Multiply** modes can overlap within the same Blueprint area. T4 still governs Bedrock, Foundation, four Pillars, explicit Drift + Return, Keystone Rhythms, Energy and living Legacy, plus actual definition/content states and the Free three-page/Full thirteen-page Blueprint exports. This new acquisition direction does not re-score CFM4, change Energy Audit items or totals, add a fifth Pillar, or make a marketing funnel a compulsory participant curriculum.

## 2. Public free Annual Retreat Guide and Free Steward boundary

Publish an accessible, substantive guide (when rights, design and release gates permit) covering: Remember & Release; Discern & Diagnose; Faith & Identity; Foundation; Family/Fitness/Fun/Finances; Guardrails; Drift + Return; Keystone Rhythms; the **existing standardized Energy Audit**; living Legacy; Restore/Build/Protect/Multiply; current-season reflection; outcomes; Evidence of Alignment; Not This Year/Release; a first-90-days plan; verified permitted Scripture references and guided examples. Keep the core promise: **“Get clear on where you really are—and what faithful stewardship looks like next.”** A participant can complete a meaningful retreat alone, off platform, without a paid account.

**Editorial discrepancy to resolve before public “Energy Audit included” advertising:** Page 26 of the currently supplied PDF tells the reader to use the standard Energy Audit *“if you have it available.”* It does **not** contain the standardized audit's complete items and scoring as a standalone integrated instrument. To say that the published download “includes the Energy Audit,” either embed the **unaltered approved instrument with appropriate source/rights handling** or provide it through a verified accessible companion within the public flow. Do not construct a new annual test or promise an instrument the download does not provide.

Free Steward may clarify a question, use the current conversation's disclosed context, explain a mode, draft a bounded candidate Rhythm/Guardrail or sentence, help interpret legitimately supplied/recorded Energy Audit evidence, and identify a useful next step. These are ordinary Free outcomes, not a Premium upsell trigger. Free interaction does not automatically include retrieval/synthesis of years of historical Blueprint records or the creation of a comprehensive personalized Annual Retreat package. A longer series of guided thirteen-page Full Blueprint redevelopment remains under the existing active Build/Premium/equivalent service boundary even if split across visits or not saved.

Acquisition through the guide cannot impose mandatory Created for More, assessment, doctrinal assent, immediate registration, payment or forced purchase as prerequisites to reading the framework. Eligibility/account protection still governs private Blueprint persistence. Whether a public PDF requires an email to **deliver** it is an explicit implementation choice not made by this directive; do not invent the gate. Any marketing enrollment remains optional, separately informed and independently chosen even when a transactional email delivers an requested guide.

## 3. Premium Annual Retreat experience and personalization contract

The Premium annual benefit uses **only actually retained, currently authorized, purpose-relevant and participant-approved** information, such as current/prior Blueprint versions and North Star; Faith & Identity wording; mission/values/purpose/calling; selected focus areas and outcomes; selected quarterly priorities; Keystone Rhythms; Guardrails; Evidence of Alignment; dated Energy Audit results; participant-chosen Restore/Build/Protect/Multiply postures; significant decisions; selected progress and accomplishments; reported answered prayers; approved milestones and transition events; appropriately selected struggles/drift/return records; prior retreat conclusions and Not This Year items. This list is an eligibility menu, **not** a request to scrape or persist everything.

No raw-chat archive, automatic autobiography, blanket transcript capture, inferred family/medical/financial history, or covert timeline is authorized. For an entry whose future use is not selected or whose consent, source status or currentness is uncertain, leave it out or ask permission as needed. Do not claim that earlier months, answered prayers, milestones or outcomes occurred if authorized records do not show them. A participant's own uncertainty and corrections govern. No personal history goes to public acquisition, analytics, marketing segmentation or checkout metadata.

The eligible active Premium package should be specified to deliver:

- Gradual optional retreat planning and small Remember & Release prompts at the selected cadence, not a giant new questionnaire.
- A personalized Year in Review indicating periods covered and absent evidence; a context-aware look at what changed from actual prior versions.
- Personalized prompts using approved facts and their dates, with natural “Does that still feel true?” checks rather than judgments.
- Current-season clarification and a nonexclusive area-by-mode Restore/Build/Protect/Multiply map.
- Guided participant-approved updates to North Star/Full Blueprint and its existing T4 states/versions, selected Evidence of Alignment and approximately 3–7 major outcomes when suitable (one faithful next step can be enough).
- A **personalized digital retreat PDF included with Premium** using the universal template's structure and only eligible approved selected content. Digital rendering/export is a separate confirmed operation; preview and private-content review controls are required.
- Optional post-retreat integration and first-90-days plan, including agreed Quarter/Monthly/Weekend/Daily review preferences where genuinely useful. Consent to a plan is not consent to messages or calendar writes.
- An **optional invitation** to consider a paid printed journal only when released and appropriate, never a requirement or the centerpiece of the reflection.

The public guide, universal teaching, critical safety help and core Legacy instruction are never gated behind Premium. Do not frame upgrading as paying to unlock “better questions,” salvation, faithfulness, personal worth or protected core teaching. Suggested participant-facing distinction from owner direction: *“The free guide gives you the complete retreat framework. Steward Premium remembers your approved Blueprint and story, helps you prepare over time, and creates a retreat experience personalized around your actual life.”* Any availability/price card must come from a released authoritative catalogue and obey the existing shared promotion/refusal/safety policy.

## 4. Retreat preference data and invitations

Proposed optional **retreat preference** object (DESIGN; physical schema and lifecycle not yet approved):

- Desire/status: `wants_annual_retreat`, `annual_retreat_status` with unknown/declined/maybe/planned/in-progress/completed interpreted accurately. A changed mind must be respected; do not convert an unanswered question into a planned retreat.
- Timing: `preferred_retreat_month`, `preferred_retreat_window`, `preferred_timing_type` (`year_end`, `new_year`, `birthday`, `steward_anniversary`, `summer`, `custom`), approximate or confirmed `next_retreat_date`, chosen timezone/date-certainty.
- Shape: `preferred_duration`, `solo_or_spouse` (preference only, not account sharing), `preferred_format` (`recommended`, `own`, `hybrid`), `retreat_location` only if volunteered and necessary.
- Outputs: `personalized_pdf_preference`, `printed_journal_interest` and `printed_journal_preference` (interest ≠ checkout assent), `journal_content_approval_status`, `print_deadline`, `journal_production_status`, `delivery_status`—print operational fields must remain unavailable/unknown until the product exists and actual provider receipts are received.
- Follow-up: `retreat_preparation_start_date`, `post_retreat_followup_date`; these are planning metadata, not independent outbound sending grants.

Every field is optional when not needed. Separate **participant-stated preference**, **participant-approved saved preference**, and **application-confirmed persistence**. Preferences are visible/editable/removable, minimal and purpose-bound; avoid repeated questions already answered. Disclosing preferred timing does not authorize future reminders, outreach, marketing, calendar events or automatic journals. After sufficient context, Steward may offer the short invitation already drafted by the owner, including the choices recommended format, own format, maybe later, and not now. “Maybe, ask me later” still needs a specified permitted later timing/channel rather than enabling generic pursuit. The participant may opt out without loss of useful service.

## 5. Preparation and year-round review cadence

The following are **optional planning windows**, not hard deadlines or automatic scheduler instructions:

| Relative to participant-chosen retreat | Intended assistance | Must not imply |
| --- | --- | --- |
| About 90–120 days | Confirm that the retreat is still wanted, approximate timing, solo/spouse preference, duration, format, location if volunteered, digital/print interest | Enrollment, permission to contact, available couples mode, print inventory or print order |
| About 60–90 days | Offer one light Remember & Release prompt at a time: meaningful moment, answered prayer if reported, milestone, important person, what changed, gratitude, hardship and learning | Blanket collection, autobiographical archive, prescribed intake quota |
| About 30–45 days | Review permitted personal context and draft digital material; if printer available, check vendor-approved cutoffs, separately selected photos, pricing and proof permissions | Printer acceptance, unapproved private data export, guaranteed ship/delivery |
| About a week before | Optional preparation/readiness checklist, available guide, chosen date and practical boundaries | Automatic email/SMS/push or calendar entry |
| After retreat | Participant-selected Blueprint/mode/outcome/Rhythm/Guardrail revisions and optional check-in around 24–48h / one week | Silent saving, time-triggered outreach, recurring commitment without separate authorization |

Annual Retreat → Quarterly Blueprint Reset → Monthly Stewardship Blueprint Reset → Weekend Blueprint Reset → Adaptive Daily Check-Ins is a **menu/cascade of useful review depths**, not a compulsory five-channel notification stack. Existing AG06 Attention Budget, purpose/channel consent, quiet hours, opt-out, deduplication and actual schedule receipts prevail. An in-conversation offer to place a Rhythm on a calendar is not an actual write. Treat elapsed time and an absent response as unknown rather than drift or failure.

## 6. Premium-only printed `My Stewardship Year` journal — deferred operational release

**Owner intent:** An optional, one-of-one keepsake/retreat workbook/legacy record—**not** a disposable planner, free guide substitute, core Gospel product, or included Premium subscription benefit. Initial intended purchase eligibility: verified participant with an active Premium service or truly equivalent released grant under explicit terms; no one-time nonsubscriber purchase path selected for the initial version. The suggested **$75–$150 retail range is exploratory**, pending actual printer quotes, personalization effort, production, shipping, fulfillment, tax and customer terms. No model-generated final price, discount, payment or sale is permitted.

**Two-stage sensitive-content approval, plus operational confirmation:**

`Steward proposes exact selected personalized content + intended print purpose → participant reviews/edits/approves each appropriate sensitive selection → final proof generated → participant affirmatively approves final proof → separately authorized paid order and fulfillment prerequisites verified → authorized application submits print-ready file → printer confirms acceptance/production/shipment/delivery as each event actually happens`.

Payment/ordering sequence may be designed with refundable/approval windows, but must be selected by commerce/fulfillment review: **proof approval is not payment authorization, and payment is not proof approval**. No upload/send to an external printer before the necessary private-content and vendor-processing permissions are established. Sensitive areas include health, medical data, finances, marriage, sexual issues, sin/spiritual struggles, child/third-party information, conflicts, journaling, family events and photos. Digital PDF approval does not grant print permission; past consent to a prior year's print does not necessarily authorize new content or a new vendor.

**Initial lead-time proposals only:** preferred final content/proof approval around 8 weeks before retreat; normal minimum around 6 weeks; hoped-for arrival about 2–3 weeks beforehand. These are not vendor-confirmed promises. Confirm printer capability, proof requirements, file/color/bleed/trim/binding, security and confidentiality, subprocessor handling, retention/deletion, child/photo rights, actual lead time, shipping regions, failed/reprint/damaged/lost shipment remedies, customer-service ownership, cost and refund policy before enabling. When timing or consent is insufficient, give the Premium personalized **digital PDF** rather than urgent-sell or false delivery guarantees. Print sale must be a distinct catalogue/checkout/receipt with its actual item/terms and must never silently create a recurring billing agreement.

A recorded `print_interest=true`, preference, a mock proof, a TEST CONTROLLER EVENT, or an emailed quote does not establish that an order was placed, file delivered to a printer, printed, shipped or received.

## 7. Couples, digital photos, and calendar are separately gated

**Spouse retreat preference** may be offered even while a full spouse retreat is future design. The envisioned model has three compartments—`My Blueprint`, `Your Blueprint`, `Our Blueprint`—not a merged record. Two adults' authentication, independent consent, selected disclosure scopes, safety fit, access revocation/deletion, disagreement handling and proofing must be engineered and tested before any sharing. Being married, named, a sponsor or an account payer does not grant access. Family retreats remain separately deferred; no child profile/participation is assumed.

**Photos** are future optional purpose-scoped source integrations for Remember & Release, timelines, printed-journal selection and meaningful milestones. The participant selects sources and images, not the AI automatically; third-party and child privacy/rights need independent review. No background phone/photo library access or bulk biographical import from this instruction.

**Calendar** is a future selected action layer: Steward may offer to add an actual chosen retreat date, Quiet-with-God time, family conversation, Sabbath, review or Rhythm **only when the integration is implemented and the participant approves that precise event, account/calendar and schedule**. A confirmed calendar provider receipt, not conversational intent, is necessary before “scheduled” wording. No silently scheduled events, no return-channel fallback, and no SMS/push feature enabled by this direction.

## 8. Website acquisition, presentation and referral-safe analytics

### 8.1 Public placement and core messaging

Make the free Annual Retreat a prominent MJG.com **Resources / Quick Access** offering; include a homepage section after the core Stewardship Blueprint explanation, a contextually appropriate Created for More follow-up, and a 6-week challenge completion invitation. Keep the actual launch contingent on website/right/compliance readiness. Show the retreat as an optional substantial resource, not a compulsory alternative to starting Steward directly or a seventh step before Free registration. The participant may take the guide and leave without a sales penalty.

Suggested public hero from owner-supplied direction:

> **When was the last time you stepped away long enough to ask: Where am I, really?**
>
> The Annual Stewardship Blueprint Retreat is a guided Christian experience designed to help you slow down, remember what God has done, honestly assess where you are, understand your current season, and identify the next faithful step.
>
> **Get the Free Retreat Guide**

Lead with the person's truth and clarity, **not** page count, a subscription price, shame, optimization, or promises of guaranteed outcomes. Position Psalm 46:10 as a referenced Scripture anchor; exact text requires the applicable publishing/AI/license review. Explain “This Is Not Another Goal Planner”: **Truth before aspiration. Clarity before goals. Stewardship before performance.** Describe four PDF phases, cross-cutting four stewardship modes, task-based pacing (multi-day/approximately three days as ideal; one day still useful), eligible actual inclusions, first/returning participant use, and privacy/human-care boundaries.

Recommended public sections: hero/Christian positioning + CTA; scripture reference; the truthful/not-a-goal-planner concept; framework; who it serves; task-based duration; actual contents; relevant Premium personalization difference; low-salience optional printed product **only if released or accurately labeled planned**; FAQ on Blueprint prerequisite, year timing, duration, spouse support, incomplete answers, truly free access, Premium benefit, personal-data privacy, and print availability. If printer unverified, FAQ states **not yet available**; do not display a functioning order CTA.

### 8.2 Entry path and attribution

Possible nonmandatory journey: `Free Annual Retreat Guide → Created for More (optional) → Free Steward / Free Blueprint → ongoing participant-initiated check-ins → qualified Premium → personalized retreat → optional separately paid print → next annual retreat`. Participants can enter or leave at any point and need not complete the assessment. Source attribution `annual_retreat_guide` may be recorded by the approved acquisition system only when technically observed and lawful/appropriate, separated from church affiliation, sponsor grants, referral relationships and personal content. No inferred signup or payment from an anonymous download; no named downstream conversion disclosed to a referrer.

Track useful noncontent events—approved page view/CTA, opt-in and delivery outcome, conversion by consented/public event category, completion feedback where explicitly volunteered—without transmitting private Blueprint notes, relationship struggles, assessment answers, journal photos or spiritual vulnerability. Exact analytics tags, provider fit, retention and applicable notice require review. Success is **real usefulness** and authentic participant choice, not time in app or a theological grade.

### 8.3 Email delivery and optional five-email series

**Email 1:** Deliver a requested guide and encourage unhurried use. **Emails 2–4:** Offer optional educational context on “Where Are You, Really?”, four modes and what success looks like without every answer. **Email 5:** Introduce Steward accurately: full free framework versus optional continuity/personalization Premium. Treat these as **draft content directions**, not sent, implemented, approved marketing copy or enabled sequences. Distinguish requested transactional delivery from **separately opted-in marketing/nurture subscription**; an email address or download does not itself authorize the entire five-email marketing sequence. Honor preferences/unsubscribe, purpose/channel distinctions, approved legal review and the existing nonpushy promotion budget where the outreach is a promotion. Do not disclose private spiritual/relationship data in outbound subject lines or sends.

## 9. Organic marketing, seasonal calendar and paid media gates

**Seasonal editorial emphasis:** November — Remember & Release, gratitude, truthful reflection, God's faithfulness. December — discern current season, Restore/Build/Protect/Multiply, Faith & Identity, Guardrails/Rhythms and a next faithful step. December 26 to January 10 — concentrated New Year's awareness: “Do not start with resolutions. Start with clarity.” Keep year-round availability for birthdays, Steward anniversaries, summer and major transitions. This is a **content plan**; not a scheduled campaign, authorized automation, purchased media plan or asserted business outcome.

Owner-supplied article concepts:

1. *Where Are You, Really? Why I Take an Annual Life Retreat* — personal flagship article; free guide invitation.
2. *Why Goal Setting Is the Wrong Place to Start Your Year* — truth before aspiration.
3. *Restore, Build, Protect, Multiply: What Season Is Your Life In?* — teach overlapping modes.
4. *Inheritance Is What You Leave. Legacy Is What You Multiply.* — discipleship, not status.

Social concepts: where am I really, gratitude, what became true, what needs restoration/protection, old-season burdens, drift/return, truth before planning, living Legacy and small faithful progress. No fabricated firsthand story or testimonial. All content should point to the actual public free guide, not a hidden Premium-only download.

**Paid-ad gate:** Do not run substantial paid traffic until the guide/Scripture rights and landing page are publication-ready, delivery and actual separately consented email follow-up work, minimal consent-aware analytics exist, CTA funnel is tested, and some genuine voluntary real-user evidence is lawfully available. A few informal fictional tests cannot be relabeled live audience evidence. Owner's preference is to test the organic funnel first and advertise the **free guide**, not cold-traffic Premium checkout, absent later actual performance evidence. No spend, audience targeting, ad account action or launch timing is authorized by this documentation.

## 10. Proposed phased execution plan and dependencies

This is the owner's intended **work order**, not evidence any step happened. Conditional publishing/rights/privacy/security/actual rollout checks remain blocking for the relevant step.

| Owner sequence | Proposed work package | Prerequisites and stopping rule |
| --- | --- | --- |
| 1 | Incorporate these new V2.0 requirements in a controlled source/change candidate | This addendum documents the proposal; active masters still require accepted publisher/source integration |
| 2 | Finalize universal Annual Retreat Guide | Editorial alignment, standard Energy Audit availability, truthful inclusion list, NIV/publication rights, accessible PDF QA |
| 3–4 | Align MJG.com terminology; build public retreat landing page | Approved copy, real CTA behavior, privacy/notice, analytics scope, no unfounded Premium/print promise |
| 5–6 | Lead capture/delivery; five-email education/nurture | Verified delivery; independent opt-in for marketing; unsubscribe, templates and consent receipts |
| 7 | Flagship article | Owner-reviewed story/provenance; actual free-guide CTA |
| 8 | Test organic journey | Realistic nonpaid end-to-end tests plus privacy and accessibility; preserve actual evidence not assumptions |
| 9–10 | Owner's planned November retreat as first **personalized Premium pilot**, then refine | Owner-supplied participation/permission and actual entitled environment or explicit synthetic fixture; no automatic Mike personal-data retrieval; no claim of test PASS until run |
| 11–12 | Physical journal prototype; qualify printer/vendor and timelines | Print approval, privacy, rights, catalog, cost/tax/refund, fulfillment/QA and production evidence; no sale before release |
| 13–14 | November/December education, New Year's amplification | Only when public materials/delivery/rights are ready; scheduling and channel permissions separate |
| 15 | Paid amplification, if organic path works | Actual verified funnel, privacy/cost review, owner advertising authorization |

**V1.0-to-V2.0 route:** The owner reports V1.0 currently under live-use-oriented implementation/testing, with bug stabilization intended before V2.0. This is a planning dependency, not a verified deployment, accepted release date, granted permission to process actual participant data, or reason to bypass testing gates. V2.0 may ship a viable core without print, photos, couples sharing, calendar or SMS; those features stay disabled until independently delivered/released. Do not advertise unreleased benefits as already available.

## 11. Source/agent/test impact, not applied to frozen masters

| Governing/source area | Proposed V2.0 change or retained invariant |
| --- | --- |
| `00_Control_Register.md` | Record new scoped change/source reference, frozen predecessor hashes and actual accepted candidate when approved |
| `02_Framework_Blueprint_Assessments.md` | Retain Bedrock/T4, explicit Drift + Return, current Free/Full exports, CFM4, exact Energy Audit and Legacy; clarify retreat is a separate public guide |
| `03_Conversation_Sensitive_Safety.md` | Free-before-selling and correct participant-first retreat navigation, no painful experience monetization, respectful invitations, referral/privacy boundaries |
| `04_Product_Journey_New_Features.md` | Public free retreat route, bounded Free Steward aid, included Premium personalized PDF, Premium-only separately paid print **target**, annual preference and cadence |
| `05_Data_Privacy_Security.md` | Purpose-limited retreat preferences/history; public acquisition vs personal records; PDF selection/exclusion; print content and final-proof approvals; actual consent/channel/vendor results |
| `06_Safety_Support_Release.md` | Sensitive retreat reflections, real-person support, public delivery, print/vendor release checks, outbound-channel suppressions and disabled integrations |
| `07_Commerce_Scripture_Rights.md` | Digital PDF included with Premium; unpriced/disabled physical SKU, independent print sale, leave DEC09 intact; NIV per-medium review |
| `08_Engineering_Experience_Operations.md` | Public download/delivery, entitlement gate, AG01–AG09 assembly, purpose-scoped render/export/print states, flags and staged rollout |
| `09_Test_Suite_Quality_Control.md` | Add focused RETF tests in separate NOT RUN specification; no overwriting D02-001 FAIL or Batch 01/02/STATE-001 evidence |
| `10_Teaching_Reference_Library.md` | Document editorial use of exact PDF template and proposed published derivative, not a blanket AI-licensed corpus |
| `11_Change_Impact_Decisions.md` | Record owner-selected product direction, 001→002 predecessor link, implementation deferrals and outstanding review questions |
| `Statement-of-Faith.txt` | **UNCHANGED**; not a target for editing |

**Functional ownership map (no extra participant-facing agent):** AG01 coordinates current access/purpose/safety/participant priority; AG02 maps approved Blueprint and precise proposed changes; AG03 retrieves only selected eligible history; AG04 compares actual reports to alignment/return without scores; AG05 drafts realistic approved Rhythms/Guardrails/first-90-days actions; AG06 manages chosen pre-retreat/review cadence under an external deterministic consent-and-sending service; AG07 interprets **unchanged** CFM4/Energy Audit; AG08 supports discerning options without claiming divine instruction; AG09 applies living Legacy. Identity, approval/persistence, PDF rendering, commerce, marketing permission, calendar, printing and dispatch remain **separate authorized application services**—never model-authorized actions.

## 12. Actual open decisions / required verification, after recording owner intent

**Resolved by this October directive, do not ask again:** the public free guide contains the complete framework; Free Steward offers bounded assistance; qualified Premium includes the personalized annual digital PDF and gradual context-aware annual service with no separate digital PDF price; the printed `My Stewardship Year` is initially Premium-only, optional and separately purchased; physical product prices/production remain unselected; five-email sequence is a target, not automatic consent; V1.0 stabilization precedes contemplated broad V2.0 migration.

**Unresolved technical or publish/commerce evidence, do not guess:**

1. MJG.com public-download mechanism and whether an email is required to *deliver* a copy; how no-account access remains genuinely useful; provider notice/consent compliance.
2. Final public guide editing and the standardized **Energy Audit discrepancy**; source and formatting checks for all actual promised included components, PDF accessibility and final filename/edition version labels.
3. Precise NIV permissions for free distribution, AI-personalized PDF, paid print and marketing content; any selected attribution and quotation constraints; page 1 already includes a short NIV Psalm 46:10 quote, other passages are placeholders. The existing controlled posture is **references + original explanation until specific scope cleared**. No invented Biblica/license approval.
4. Premium feature flag, historical retrieval-purpose grants, digital render/export/provider integration, entitlement test evidence, per-user/year operating usage policy and minimal retention/deletion/derivative behavior.
5. Print vendor/binding/materials/proofing, sensitive-data processing/subprocessors, licensing, shipping and lead-time proof, actual per-unit costs, precise SKU/eligibility/rules, taxes, cancellation/refund/returns and customer support before any real order.
6. Explicit roles/sharing/revocation for future couples edition, future photos, connected calendar and SMS/push; no early activation from preferences.
7. Public delivery, consent-aware analytics, marketing service compliance, email opt-in/unsubscribe, actual organic funnel, campaign budget and qualified release sign-off; no untested paid advertising.
8. Migration scope from reported V1.0 testing to an accepted V2.0 release; candidate digest, actual staging/application/rights/security/safety evidence and rollback plan. Preserve purchased snapshots, selected continuity, deletion and earlier test evidence.

## 13. Evidence, version, and provenance rules

All `RETF-*` cases in the companion test specification are **NOT RUN**. Prior Draft 0.3 D02-001 conversational FAIL, Batch 01/02 scoped evidence, B02-EVIDENCE-LABEL-001, DEF-B02-FREE-SCOPE-001 until retested, and STATE-001 historical failure remain visible; no new testing outcome overwrites them. A fictional TEST CONTROLLER EVENT is only a fictional conversational result—not real application proof. No account creation, receipt, schedule, note, journal order, shipped product, payment, newsletter subscription, publisher approval, rights clearance, publisher installation, live website edit, production promotion, or customer message occurred by preparing this documentation.

**Reference source identities:**

- The original owner-uploaded `Annual_Stewardship_Blueprint_Retreat_Guide_v2_Scripture_Review.pdf` is retained unchanged with SHA-256 `58c7885329f749b2276052ff490dcbd4f064f2d043e330144b093a010cf8a4bd`. Internally it says *Free Annual Retreat Guide • Version 1.0*; that does not define the Steward application version.
- `CHG-V2-RETREAT-001_Source_Registration_and_Product_Direction.md` remains the source-template and core retreat logic registration, SHA-256 `74f27f5ada710302b4029a304a7de1dcd81648824360ba4730f2c642f709e1ae`.
- This `CHG-V2-RETREAT-002` records owner-provided **new business/product direction** in the current conversation. It is an authored implementation interpretation, **not a verbatim saved transcript**. Exact representative owner sentences and the 28-section original remain in that conversation as provenance. It does not replace the 001 addendum or historical governed product/source text.

**Controlled incorporation:** Future accepted V2.0 update should route the exact new clauses into current sections of the twelve masters under an authorized change package, then produce new instructions/serving maps, source and rights allowlists, feature flags, test selection and rollback instructions. This is not a stealth modification of Draft 0.6.2 or an assertion that this Project's governing source set is installed with 002.
